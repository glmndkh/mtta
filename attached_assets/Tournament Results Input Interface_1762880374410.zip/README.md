
  # Tournament Results Input Interface

  This is a code bundle for Tournament Results Input Interface. The original project is available at https://www.figma.com/design/tnE00xQrz6yOb0YK2yYzUx/Tournament-Results-Input-Interface.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  