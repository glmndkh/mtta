import { useState } from "react";
import { FormatSelection } from "./components/FormatSelection";
import { GroupStageView } from "./components/GroupStageView";
import { PlayoffView } from "./components/PlayoffView";

export type EventType = "singles" | "doubles" | "team";
export type Category = "men" | "women" | "u15" | "veteran";
export type Format = "group" | "playoff";

export interface TournamentConfig {
  format: Format;
  eventType: EventType;
  category: Category;
}

export default function App() {
  const [config, setConfig] = useState<TournamentConfig | null>(null);

  const handleConfigSelect = (newConfig: TournamentConfig) => {
    // For doubles, force playoff format
    if (newConfig.eventType === "doubles") {
      setConfig({ ...newConfig, format: "playoff" });
    } else {
      setConfig(newConfig);
    }
  };

  const handleBack = () => {
    setConfig(null);
  };

  if (!config) {
    return <FormatSelection onSelect={handleConfigSelect} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {config.format === "group" && (
        <GroupStageView config={config} onBack={handleBack} />
      )}
      {config.format === "playoff" && (
        <PlayoffView config={config} onBack={handleBack} />
      )}
    </div>
  );
}
