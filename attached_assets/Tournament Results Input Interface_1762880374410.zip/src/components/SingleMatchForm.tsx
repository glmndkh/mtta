import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card } from "./ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Plus, Save, X } from "lucide-react";

interface SingleMatchFormProps {
  onSave: () => void;
  onCancel: () => void;
}

interface SetScore {
  player1: string;
  player2: string;
}

export function SingleMatchForm({ onSave, onCancel }: SingleMatchFormProps) {
  const [sets, setSets] = useState<SetScore[]>([
    { player1: "", player2: "" },
    { player1: "", player2: "" },
    { player1: "", player2: "" },
  ]);

  const addSet = () => {
    if (sets.length < 7) {
      setSets([...sets, { player1: "", player2: "" }]);
    }
  };

  const updateSet = (index: number, player: "player1" | "player2", value: string) => {
    const newSets = [...sets];
    newSets[index][player] = value;
    setSets(newSets);
  };

  const calculateWinner = () => {
    let player1Wins = 0;
    let player2Wins = 0;

    sets.forEach((set) => {
      const p1Score = parseInt(set.player1) || 0;
      const p2Score = parseInt(set.player2) || 0;
      if (p1Score > p2Score) player1Wins++;
      if (p2Score > p1Score) player2Wins++;
    });

    if (player1Wins > player2Wins && player1Wins >= 3) return "player1";
    if (player2Wins > player1Wins && player2Wins >= 3) return "player2";
    return null;
  };

  const winner = calculateWinner();

  const player1 = {
    name: "Б. Энхболд",
    club: "Улаанбаатар клуб",
    photo: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=200",
  };

  const player2 = {
    name: "Д. Бат-Эрдэнэ",
    club: "Монгол Алтан клуб",
    photo: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200",
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-[1fr_auto_1fr] gap-8">
        {/* Player 1 */}
        <Card className={`p-6 ${winner === "player1" ? "border-2 border-emerald-500 bg-emerald-50" : "bg-gray-50"}`}>
          <div className="flex flex-col items-center text-center gap-4">
            <Avatar className="w-24 h-24 border-4 border-white shadow-lg">
              <AvatarImage src={player1.photo} />
              <AvatarFallback>{player1.name[0]}</AvatarFallback>
            </Avatar>
            <div>
              <h3 className="text-gray-900">{player1.name}</h3>
              <p className="text-gray-600">{player1.club}</p>
            </div>
          </div>
        </Card>

        {/* Score Input */}
        <div className="min-w-[240px] space-y-3">
          <div className="text-center mb-4">
            <div className="text-gray-500 mb-2">Сетийн оноо</div>
            <div className="flex justify-center gap-3">
              <div className="text-2xl text-emerald-600">
                {sets.filter((s) => parseInt(s.player1) > parseInt(s.player2) && s.player1 && s.player2).length}
              </div>
              <div className="text-2xl text-gray-300">-</div>
              <div className="text-2xl text-emerald-600">
                {sets.filter((s) => parseInt(s.player2) > parseInt(s.player1) && s.player1 && s.player2).length}
              </div>
            </div>
          </div>

          {sets.map((set, index) => (
            <div key={index} className="flex items-center gap-2 bg-gray-50 p-3 rounded-lg">
              <span className="text-gray-500 min-w-[50px]">Сет {index + 1}</span>
              <Input
                type="number"
                value={set.player1}
                onChange={(e) => updateSet(index, "player1", e.target.value)}
                className="w-16 h-10 text-center"
                placeholder="0"
                min="0"
              />
              <span className="text-gray-400">:</span>
              <Input
                type="number"
                value={set.player2}
                onChange={(e) => updateSet(index, "player2", e.target.value)}
                className="w-16 h-10 text-center"
                placeholder="0"
                min="0"
              />
            </div>
          ))}

          {sets.length < 7 && (
            <Button
              variant="outline"
              onClick={addSet}
              className="w-full border-emerald-200 text-emerald-700 hover:bg-emerald-50"
            >
              <Plus className="w-4 h-4 mr-2" />
              Сет нэмэх
            </Button>
          )}
        </div>

        {/* Player 2 */}
        <Card className={`p-6 ${winner === "player2" ? "border-2 border-emerald-500 bg-emerald-50" : "bg-gray-50"}`}>
          <div className="flex flex-col items-center text-center gap-4">
            <Avatar className="w-24 h-24 border-4 border-white shadow-lg">
              <AvatarImage src={player2.photo} />
              <AvatarFallback>{player2.name[0]}</AvatarFallback>
            </Avatar>
            <div>
              <h3 className="text-gray-900">{player2.name}</h3>
              <p className="text-gray-600">{player2.club}</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Actions */}
      <div className="flex justify-end gap-3 pt-4 border-t">
        <Button variant="outline" onClick={onCancel}>
          <X className="w-4 h-4 mr-2" />
          Цуцлах
        </Button>
        <Button onClick={onSave} className="bg-emerald-600 hover:bg-emerald-700">
          <Save className="w-4 h-4 mr-2" />
          Үр дүн хадгалах
        </Button>
      </div>
    </div>
  );
}
