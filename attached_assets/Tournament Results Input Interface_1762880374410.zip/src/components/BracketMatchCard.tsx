import { Card } from "./ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Trophy, Plus } from "lucide-react";
import { EventType } from "../App";

interface Participant {
  name: string;
  photo: string;
  club: string;
}

interface Match {
  id: string;
  participant1?: Participant;
  participant2?: Participant;
  score?: string;
  winner?: "participant1" | "participant2";
}

interface BracketMatchCardProps {
  match: Match;
  onClick: () => void;
  eventType: EventType;
  isHighlight?: boolean;
}

export function BracketMatchCard({ match, onClick, eventType, isHighlight }: BracketMatchCardProps) {
  const isEmpty = !match.participant1 && !match.participant2;

  return (
    <Card
      onClick={onClick}
      className={`cursor-pointer transition-all duration-300 overflow-hidden ${
        isHighlight
          ? "border-2 border-emerald-600 shadow-2xl hover:shadow-3xl bg-gradient-to-br from-emerald-50 to-white"
          : "border border-gray-200 hover:border-emerald-500 hover:shadow-xl bg-white"
      }`}
    >
      {isEmpty ? (
        <div className="p-8 flex flex-col items-center justify-center gap-4 bg-gray-50 min-h-[160px]">
          <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center">
            <Plus className="w-6 h-6 text-gray-400" />
          </div>
          <span className="text-gray-500">
            {eventType === "team" ? "Баг оруулах" : eventType === "doubles" ? "Хос оруулах" : "Тоглогч оруулах"}
          </span>
        </div>
      ) : (
        <div className="min-w-[340px]">
          {/* Participant 1 */}
          <div
            className={`p-5 flex items-center gap-4 transition-all ${
              match.winner === "participant1"
                ? "bg-gradient-to-r from-emerald-100 to-emerald-50 border-b-2 border-emerald-600"
                : "bg-white border-b border-gray-200 hover:bg-gray-50"
            }`}
          >
            {match.participant1 ? (
              <>
                <Avatar className="w-14 h-14 border-2 border-white shadow-md">
                  <AvatarImage src={match.participant1.photo} />
                  <AvatarFallback>{match.participant1.name[0]}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="text-gray-900 truncate">{match.participant1.name}</div>
                  <div className="text-gray-500 truncate">{match.participant1.club}</div>
                </div>
                {match.winner === "participant1" && (
                  <Trophy className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                )}
                {match.score && (
                  <div className="text-xl text-gray-900 min-w-[40px] text-right">
                    {match.score.split("-")[0]}
                  </div>
                )}
              </>
            ) : (
              <div className="text-gray-400 py-3">TBD</div>
            )}
          </div>

          {/* Participant 2 */}
          <div
            className={`p-5 flex items-center gap-4 transition-all ${
              match.winner === "participant2"
                ? "bg-gradient-to-r from-emerald-100 to-emerald-50 border-t-2 border-emerald-600"
                : "bg-white hover:bg-gray-50"
            }`}
          >
            {match.participant2 ? (
              <>
                <Avatar className="w-14 h-14 border-2 border-white shadow-md">
                  <AvatarImage src={match.participant2.photo} />
                  <AvatarFallback>{match.participant2.name[0]}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="text-gray-900 truncate">{match.participant2.name}</div>
                  <div className="text-gray-500 truncate">{match.participant2.club}</div>
                </div>
                {match.winner === "participant2" && (
                  <Trophy className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                )}
                {match.score && (
                  <div className="text-xl text-gray-900 min-w-[40px] text-right">
                    {match.score.split("-")[1]}
                  </div>
                )}
              </>
            ) : (
              <div className="text-gray-400 py-3">TBD</div>
            )}
          </div>
        </div>
      )}
      
      {isHighlight && !isEmpty && (
        <div className="h-1.5 bg-gradient-to-r from-emerald-600 to-emerald-700"></div>
      )}
    </Card>
  );
}
