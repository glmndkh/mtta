import { Card } from "./ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Trophy } from "lucide-react";

interface Player {
  name: string;
  club: string;
  photo: string;
}

interface PlayerCardProps {
  player: Player;
  isWinner: boolean;
  position: "left" | "right";
}

export function PlayerCard({ player, isWinner, position }: PlayerCardProps) {
  return (
    <Card
      className={`p-6 transition-all duration-300 ${
        isWinner
          ? "border-emerald-500 border-2 bg-gradient-to-br from-emerald-50 to-white shadow-xl"
          : "border-gray-200 bg-white"
      }`}
    >
      <div className="flex flex-col items-center text-center space-y-4">
        <div className="relative">
          <Avatar className="w-32 h-32 border-4 border-white shadow-lg">
            <AvatarImage src={player.photo} />
            <AvatarFallback className="bg-emerald-100 text-emerald-700">
              {player.name[0]}
            </AvatarFallback>
          </Avatar>
          {isWinner && (
            <div className="absolute -top-2 -right-2 w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center shadow-lg">
              <Trophy className="w-6 h-6 text-white" />
            </div>
          )}
        </div>

        <div>
          <h3 className="text-gray-900 mb-1">{player.name}</h3>
          <p className="text-gray-500">{player.club}</p>
        </div>

        {isWinner && (
          <div className="inline-block px-6 py-2 bg-emerald-600 text-white rounded-full shadow-lg">
            Ялагч
          </div>
        )}
      </div>
    </Card>
  );
}
