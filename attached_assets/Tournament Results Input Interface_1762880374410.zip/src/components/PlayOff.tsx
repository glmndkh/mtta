import { useState } from "react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { ArrowLeft, Trophy, Plus } from "lucide-react";
import { EventType } from "../App";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog";
import { MatchResultForm } from "./MatchResultForm";
import { BracketMatch } from "./BracketMatch";

interface PlayOffProps {
  eventType: EventType;
  onBack: () => void;
}

interface Match {
  id: string;
  player1?: { name: string; photo: string; club: string };
  player2?: { name: string; photo: string; club: string };
  score?: string;
  winner?: "player1" | "player2";
}

export function PlayOff({ eventType, onBack }: PlayOffProps) {
  const [selectedMatch, setSelectedMatch] = useState<string | null>(null);
  const [showMatchDialog, setShowMatchDialog] = useState(false);

  const [matches, setMatches] = useState<Record<string, Match>>({
    // Quarterfinals
    q1: {
      id: "q1",
      player1: {
        name: "Б. Энхболд",
        photo: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=100",
        club: "Улаанбаатар клуб",
      },
      player2: {
        name: "Л. Ганзориг",
        photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100",
        club: "Эрдэнэт клуб",
      },
      score: "3-0",
      winner: "player1",
    },
    q2: {
      id: "q2",
      player1: {
        name: "Г. Мөнхбат",
        photo: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100",
        club: "Монгол Алтан клуб",
      },
      player2: {
        name: "Н. Түвшинбаяр",
        photo: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100",
        club: "Их Монгол клуб",
      },
      score: "3-2",
      winner: "player1",
    },
    q3: {
      id: "q3",
      player1: {
        name: "Д. Бат-Эрдэнэ",
        photo: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100",
        club: "Эрдэнэт клуб",
      },
      player2: {
        name: "Ч. Өнөрбаяр",
        photo: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=100",
        club: "Их Монгол клуб",
      },
    },
    q4: {
      id: "q4",
      player1: {
        name: "А. Болорчулуун",
        photo: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100",
        club: "Улаанбаатар клуб",
      },
      player2: {
        name: "С. Батбаяр",
        photo: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=100",
        club: "Монгол Алтан клуб",
      },
    },
    // Semifinals
    s1: {
      id: "s1",
      player1: {
        name: "Б. Энхболд",
        photo: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=100",
        club: "Улаанбаатар клуб",
      },
      player2: {
        name: "Г. Мөнхбат",
        photo: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100",
        club: "Монгол Алтан клуб",
      },
    },
    s2: {
      id: "s2",
    },
    // Final
    final: {
      id: "final",
    },
    // Third Place
    third: {
      id: "third",
    },
  });

  const getEventTypeName = () => {
    switch (eventType) {
      case "single":
        return "Ганцаарчилсан";
      case "team":
        return "Баг";
      case "doubles":
        return "Хос";
    }
  };

  const handleMatchClick = (matchId: string) => {
    setSelectedMatch(matchId);
    setShowMatchDialog(true);
  };

  return (
    <div className="min-h-screen p-8">
      <div className="max-w-[1800px] mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button
            variant="outline"
            onClick={onBack}
            className="border-gray-300 hover:border-emerald-500"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Буцах
          </Button>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-emerald-600 rounded-xl flex items-center justify-center">
              <Trophy className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-gray-900">Шууд шат - Play-Off</h1>
              <p className="text-gray-600">{getEventTypeName()} - Bracket тогтолцоо</p>
            </div>
          </div>
          <div className="w-32"></div>
        </div>

        {/* Bracket */}
        <Card className="p-8 bg-white shadow-xl border-gray-200">
          <div className="grid grid-cols-[1fr_auto_1fr_auto_1fr] gap-8">
            {/* Quarterfinals Left */}
            <div className="space-y-6">
              <h3 className="text-gray-700 text-center mb-6">Шилдэг 8</h3>
              <div className="space-y-32">
                <BracketMatch
                  match={matches.q1}
                  onClick={() => handleMatchClick("q1")}
                />
                <BracketMatch
                  match={matches.q2}
                  onClick={() => handleMatchClick("q2")}
                />
              </div>
            </div>

            {/* Connector Lines 1 */}
            <div className="flex flex-col justify-around py-16">
              <svg width="60" height="400" className="overflow-visible">
                <path
                  d="M 0 80 L 30 80 L 30 200 M 30 200 L 60 200"
                  stroke="#d1d5db"
                  strokeWidth="2"
                  fill="none"
                />
                <path
                  d="M 0 320 L 30 320 L 30 200"
                  stroke="#d1d5db"
                  strokeWidth="2"
                  fill="none"
                />
              </svg>
            </div>

            {/* Semifinals */}
            <div className="space-y-6">
              <h3 className="text-gray-700 text-center mb-6">Хагас шигшээ</h3>
              <div className="space-y-64 pt-24">
                <BracketMatch
                  match={matches.s1}
                  onClick={() => handleMatchClick("s1")}
                />
                <BracketMatch
                  match={matches.s2}
                  onClick={() => handleMatchClick("s2")}
                />
              </div>
            </div>

            {/* Connector Lines 2 */}
            <div className="flex flex-col justify-center py-16">
              <svg width="60" height="600" className="overflow-visible">
                <path
                  d="M 0 200 L 30 200 L 30 300 M 30 300 L 60 300"
                  stroke="#d1d5db"
                  strokeWidth="2"
                  fill="none"
                />
                <path
                  d="M 0 400 L 30 400 L 30 300"
                  stroke="#d1d5db"
                  strokeWidth="2"
                  fill="none"
                />
              </svg>
            </div>

            {/* Finals */}
            <div className="space-y-6">
              <h3 className="text-gray-700 text-center mb-6">Финал</h3>
              <div className="pt-48">
                <BracketMatch
                  match={matches.final}
                  onClick={() => handleMatchClick("final")}
                  isHighlight
                />
                <div className="mt-32">
                  <h4 className="text-gray-600 text-center mb-4">3-р байрны тоглолт</h4>
                  <BracketMatch
                    match={matches.third}
                    onClick={() => handleMatchClick("third")}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Quarterfinals Right */}
          <div className="absolute top-[120px] left-8">
            <div className="space-y-32">
              <BracketMatch
                match={matches.q3}
                onClick={() => handleMatchClick("q3")}
              />
              <BracketMatch
                match={matches.q4}
                onClick={() => handleMatchClick("q4")}
              />
            </div>
          </div>
        </Card>

        {/* Instructions */}
        <div className="mt-6 text-center text-gray-600">
          <p>Тоглолтын үр дүн оруулахын тулд bracket дээрх тоглолт дээр дарна уу</p>
        </div>
      </div>

      {/* Match Result Dialog */}
      <Dialog open={showMatchDialog} onOpenChange={setShowMatchDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Тоглолтын үр дүн оруулах</DialogTitle>
          </DialogHeader>
          <MatchResultForm
            eventType={eventType}
            onSave={() => setShowMatchDialog(false)}
            onCancel={() => setShowMatchDialog(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
