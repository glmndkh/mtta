import { EventType } from "../App";
import { SinglesMatchInput } from "./SinglesMatchInput";
import { DoublesMatchInput } from "./DoublesMatchInput";
import { TeamMatchInput } from "./TeamMatchInput";

interface MatchResultInputProps {
  eventType: EventType;
  onSave: () => void;
  onCancel: () => void;
}

export function MatchResultInput({ eventType, onSave, onCancel }: MatchResultInputProps) {
  return (
    <div>
      {eventType === "singles" && <SinglesMatchInput onSave={onSave} onCancel={onCancel} />}
      {eventType === "doubles" && <DoublesMatchInput onSave={onSave} onCancel={onCancel} />}
      {eventType === "team" && <TeamMatchInput onSave={onSave} onCancel={onCancel} />}
    </div>
  );
}
