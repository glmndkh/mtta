import { useState } from "react";
import { Button } from "./ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import { Card } from "./ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { ArrowLeft, Plus, Trophy, CheckCircle2, XCircle, Table2 } from "lucide-react";
import { TournamentConfig } from "../App";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog";
import { MatchResultInput } from "./MatchResultInput";

interface GroupStageViewProps {
  config: TournamentConfig;
  onBack: () => void;
}

interface Standing {
  id: number;
  name: string;
  photo: string;
  club: string;
  mp: number;
  w: number;
  l: number;
  sw: number;
  sl: number;
  sd: number;
  pts: number;
  qualified: boolean;
}

export function GroupStageView({ config, onBack }: GroupStageViewProps) {
  const [selectedGroup, setSelectedGroup] = useState("A");
  const [showMatchDialog, setShowMatchDialog] = useState(false);

  const standings: Standing[] = [
    {
      id: 1,
      name: config.eventType === "team" ? "Улаанбаатар клуб" : "Б. Энхболд",
      photo: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=100",
      club: "Улаанбаатар клуб",
      mp: 3,
      w: 3,
      l: 0,
      sw: 9,
      sl: 2,
      sd: 7,
      pts: 9,
      qualified: true,
    },
    {
      id: 2,
      name: config.eventType === "team" ? "Монгол Алтан клуб" : "Г. Мөнхбат",
      photo: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100",
      club: "Монгол Алтан клуб",
      mp: 3,
      w: 2,
      l: 1,
      sw: 7,
      sl: 5,
      sd: 2,
      pts: 6,
      qualified: true,
    },
    {
      id: 3,
      name: config.eventType === "team" ? "Их Монгол клуб" : "Н. Түвшинбаяр",
      photo: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100",
      club: "Их Монгол клуб",
      mp: 3,
      w: 1,
      l: 2,
      sw: 5,
      sl: 7,
      sd: -2,
      pts: 3,
      qualified: false,
    },
    {
      id: 4,
      name: config.eventType === "team" ? "Эрдэнэт клуб" : "Л. Ганзориг",
      photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100",
      club: "Эрдэнэт клуб",
      mp: 3,
      w: 0,
      l: 3,
      sw: 2,
      sl: 9,
      sd: -7,
      pts: 0,
      qualified: false,
    },
  ];

  const getEventTypeName = () => {
    switch (config.eventType) {
      case "singles":
        return "Ганцаарчилсан";
      case "team":
        return "Багийн";
      case "doubles":
        return "Хос";
    }
  };

  const getCategoryName = () => {
    switch (config.category) {
      case "men":
        return "Эрэгтэй";
      case "women":
        return "Эмэгтэй";
      case "u15":
        return "U15";
      case "veteran":
        return "Ахмадууд";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
          <div className="flex items-center justify-between">
            <Button
              variant="outline"
              onClick={onBack}
              className="border-gray-300 hover:border-emerald-500 h-11"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Буцах
            </Button>
            
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-emerald-600 to-emerald-700 rounded-xl flex items-center justify-center shadow-lg">
                <Table2 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-gray-900">Шигшээ хүртэлх хэсэг - Бүлгийн байрлал</h1>
                <div className="flex items-center gap-3 mt-1">
                  <Badge className="bg-emerald-100 text-emerald-700 border-0">
                    {getEventTypeName()}
                  </Badge>
                  <Badge className="bg-blue-100 text-blue-700 border-0">
                    {getCategoryName()}
                  </Badge>
                </div>
              </div>
            </div>

            <div className="w-24"></div>
          </div>
        </div>

        {/* Controls */}
        <Card className="p-6 mb-6 bg-white shadow-lg border-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div>
                <label className="text-gray-700 mb-2 block">Бүлэг сонгох</label>
                <Select value={selectedGroup} onValueChange={setSelectedGroup}>
                  <SelectTrigger className="h-12 w-48 bg-white border-gray-300">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="A">Бүлэг А</SelectItem>
                    <SelectItem value="B">Бүлэг Б</SelectItem>
                    <SelectItem value="C">Бүлэг С</SelectItem>
                    <SelectItem value="D">Бүлэг Д</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button
              onClick={() => setShowMatchDialog(true)}
              className="bg-emerald-600 hover:bg-emerald-700 h-12 px-8 shadow-lg"
            >
              <Plus className="w-5 h-5 mr-2" />
              Тоглолтын үр дүн нэмэх
            </Button>
          </div>
        </Card>

        {/* Standings Table */}
        <Card className="bg-white shadow-xl border-0 overflow-hidden">
          <div className="bg-gradient-to-r from-emerald-600 to-emerald-700 px-6 py-5">
            <h2 className="text-white">Бүлэг {selectedGroup} - Байрлал хүснэгт</h2>
          </div>

          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50 hover:bg-gray-50 border-b-2 border-gray-200">
                  <TableHead className="w-16 text-center">#</TableHead>
                  <TableHead className="min-w-[300px]">
                    {config.eventType === "team" ? "Багийн нэр" : config.eventType === "doubles" ? "Хос" : "Тоглогчийн нэр"}
                  </TableHead>
                  <TableHead className="text-center w-24">MP</TableHead>
                  <TableHead className="text-center w-24">W</TableHead>
                  <TableHead className="text-center w-24">L</TableHead>
                  <TableHead className="text-center w-24">SW</TableHead>
                  <TableHead className="text-center w-24">SL</TableHead>
                  <TableHead className="text-center w-24">SD</TableHead>
                  <TableHead className="text-center w-32">PTS</TableHead>
                  <TableHead className="text-center w-40">Статус</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {standings.map((standing, index) => (
                  <TableRow
                    key={standing.id}
                    className={`${
                      standing.qualified ? "bg-emerald-50/50 hover:bg-emerald-50" : "hover:bg-gray-50"
                    } transition-colors border-b border-gray-100`}
                  >
                    <TableCell className="text-center">
                      <div
                        className={`w-10 h-10 rounded-full flex items-center justify-center mx-auto shadow-sm ${
                          index === 0
                            ? "bg-gradient-to-br from-amber-400 to-amber-500 text-white"
                            : index === 1
                            ? "bg-gradient-to-br from-gray-300 to-gray-400 text-white"
                            : index === 2
                            ? "bg-gradient-to-br from-orange-500 to-orange-600 text-white"
                            : "bg-gray-100 text-gray-600"
                        }`}
                      >
                        {index + 1}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-4 py-2">
                        <Avatar className="w-14 h-14 border-2 border-white shadow-md">
                          <AvatarImage src={standing.photo} />
                          <AvatarFallback>{standing.name[0]}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="text-gray-900">{standing.name}</div>
                          <div className="text-gray-500">{standing.club}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-center text-gray-700">
                      {standing.mp}
                    </TableCell>
                    <TableCell className="text-center text-emerald-700">
                      {standing.w}
                    </TableCell>
                    <TableCell className="text-center text-red-600">
                      {standing.l}
                    </TableCell>
                    <TableCell className="text-center text-gray-700">
                      {standing.sw}
                    </TableCell>
                    <TableCell className="text-center text-gray-700">
                      {standing.sl}
                    </TableCell>
                    <TableCell className="text-center">
                      <span
                        className={
                          standing.sd > 0
                            ? "text-emerald-700"
                            : standing.sd < 0
                            ? "text-red-600"
                            : "text-gray-600"
                        }
                      >
                        {standing.sd > 0 ? "+" : ""}
                        {standing.sd}
                      </span>
                    </TableCell>
                    <TableCell className="text-center text-gray-900">
                      {standing.pts}
                    </TableCell>
                    <TableCell className="text-center">
                      {standing.qualified ? (
                        <Badge className="bg-emerald-100 text-emerald-700 border-0 shadow-sm">
                          <CheckCircle2 className="w-3.5 h-3.5 mr-1.5" />
                          Шигшсэн
                        </Badge>
                      ) : (
                        <Badge className="bg-red-100 text-red-700 border-0 shadow-sm">
                          <XCircle className="w-3.5 h-3.5 mr-1.5" />
                          Хасагдсан
                        </Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* Legend */}
          <div className="bg-gray-50 px-6 py-4 border-t border-gray-200">
            <div className="flex items-center justify-center gap-6 text-gray-600 flex-wrap">
              <div className="flex items-center gap-2">
                <span className="text-gray-700">MP</span>
                <span>=</span>
                <span>Matches Played</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-gray-700">W</span>
                <span>=</span>
                <span>Wins</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-gray-700">L</span>
                <span>=</span>
                <span>Losses</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-gray-700">SW / SL</span>
                <span>=</span>
                <span>Sets Won / Lost</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-gray-700">SD</span>
                <span>=</span>
                <span>Set Difference</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-gray-700">PTS</span>
                <span>=</span>
                <span>Points</span>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Match Result Dialog */}
      <Dialog open={showMatchDialog} onOpenChange={setShowMatchDialog}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-gray-900">
              Тоглолтын үр дүн оруулах - Бүлэг {selectedGroup}
            </DialogTitle>
          </DialogHeader>
          <MatchResultInput
            eventType={config.eventType}
            onSave={() => setShowMatchDialog(false)}
            onCancel={() => setShowMatchDialog(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
