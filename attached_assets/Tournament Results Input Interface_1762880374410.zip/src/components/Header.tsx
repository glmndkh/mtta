import { Trophy, Calendar } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { Badge } from "./ui/badge";

interface HeaderProps {
  eventType: string;
  setEventType: (value: string) => void;
  roundType: string;
  setRoundType: (value: string) => void;
}

export function Header({ eventType, setEventType, roundType, setRoundType }: HeaderProps) {
  return (
    <header className="bg-gradient-to-r from-emerald-600 to-emerald-700 rounded-2xl shadow-2xl p-8 text-white">
      <div className="flex items-start justify-between mb-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-white rounded-xl flex items-center justify-center">
            <Trophy className="w-9 h-9 text-emerald-600" />
          </div>
          <div>
            <h1 className="text-white mb-1">Тэмцээний үр дүн оруулах</h1>
            <p className="text-emerald-100 opacity-90">Ширээний теннисний Аварга Шалгаруулах Тэмцээн 2025</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant="secondary" className="bg-white/20 text-white border-0 px-4 py-2">
            <Calendar className="w-4 h-4 mr-2" />
            2025.11.11
          </Badge>
          <Badge variant="secondary" className="bg-white/20 text-white border-0 px-4 py-2">
            Эрэгтэй
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="text-emerald-100 mb-2 block">Тэмцээний төрөл</label>
          <Select value={eventType} onValueChange={setEventType}>
            <SelectTrigger className="bg-white/10 border-white/20 text-white h-12 backdrop-blur-sm hover:bg-white/20 transition-colors">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="single">Ганцаарчилсан</SelectItem>
              <SelectItem value="team">Баг</SelectItem>
              <SelectItem value="doubles">Хос</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="text-emerald-100 mb-2 block">Үе шат</label>
          <Select value={roundType} onValueChange={setRoundType}>
            <SelectTrigger className="bg-white/10 border-white/20 text-white h-12 backdrop-blur-sm hover:bg-white/20 transition-colors">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="group">Шигшээ хүртэлх хэсгийн тоглолт</SelectItem>
              <SelectItem value="quarter">Шууд шат - Шилдэг 8</SelectItem>
              <SelectItem value="semi">Шууд шат - Хагас шигшээ</SelectItem>
              <SelectItem value="final">Шууд шат - Финал</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </header>
  );
}
