import { Card } from "./ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Trophy, Plus } from "lucide-react";
import { Button } from "./ui/button";

interface Player {
  name: string;
  photo: string;
  club: string;
}

interface Match {
  id: string;
  player1?: Player;
  player2?: Player;
  score?: string;
  winner?: "player1" | "player2";
}

interface BracketMatchProps {
  match: Match;
  onClick: () => void;
  isHighlight?: boolean;
}

export function BracketMatch({ match, onClick, isHighlight }: BracketMatchProps) {
  const isEmpty = !match.player1 && !match.player2;

  return (
    <Card
      onClick={onClick}
      className={`cursor-pointer transition-all duration-300 hover:shadow-xl overflow-hidden ${
        isHighlight
          ? "border-2 border-emerald-500 shadow-lg"
          : "border border-gray-200 hover:border-emerald-400"
      }`}
    >
      {isEmpty ? (
        <div className="p-6 flex flex-col items-center justify-center gap-3 bg-gray-50 min-h-[140px]">
          <Plus className="w-8 h-8 text-gray-400" />
          <span className="text-gray-500">Тоглогч оруулах</span>
        </div>
      ) : (
        <div className="min-w-[320px]">
          {/* Player 1 */}
          <div
            className={`p-4 flex items-center gap-3 transition-colors ${
              match.winner === "player1"
                ? "bg-gradient-to-r from-emerald-50 to-emerald-100 border-b-2 border-emerald-500"
                : "bg-white border-b border-gray-200"
            }`}
          >
            {match.player1 ? (
              <>
                <Avatar className="w-12 h-12 border-2 border-white shadow-sm">
                  <AvatarImage src={match.player1.photo} />
                  <AvatarFallback>{match.player1.name[0]}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="text-gray-900 truncate">{match.player1.name}</div>
                  <div className="text-gray-500 truncate">{match.player1.club}</div>
                </div>
                {match.winner === "player1" && (
                  <Trophy className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                )}
                {match.score && (
                  <div className="text-gray-900 min-w-[40px] text-right">
                    {match.score.split("-")[0]}
                  </div>
                )}
              </>
            ) : (
              <div className="text-gray-400 py-2">TBD</div>
            )}
          </div>

          {/* Player 2 */}
          <div
            className={`p-4 flex items-center gap-3 transition-colors ${
              match.winner === "player2"
                ? "bg-gradient-to-r from-emerald-50 to-emerald-100 border-t-2 border-emerald-500"
                : "bg-white"
            }`}
          >
            {match.player2 ? (
              <>
                <Avatar className="w-12 h-12 border-2 border-white shadow-sm">
                  <AvatarImage src={match.player2.photo} />
                  <AvatarFallback>{match.player2.name[0]}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="text-gray-900 truncate">{match.player2.name}</div>
                  <div className="text-gray-500 truncate">{match.player2.club}</div>
                </div>
                {match.winner === "player2" && (
                  <Trophy className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                )}
                {match.score && (
                  <div className="text-gray-900 min-w-[40px] text-right">
                    {match.score.split("-")[1]}
                  </div>
                )}
              </>
            ) : (
              <div className="text-gray-400 py-2">TBD</div>
            )}
          </div>
        </div>
      )}
    </Card>
  );
}
