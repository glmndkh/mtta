import { useState } from "react";
import { EventType } from "../App";
import { SingleMatchForm } from "./SingleMatchForm";
import { TeamMatchForm } from "./TeamMatchForm";
import { DoublesMatchForm } from "./DoublesMatchForm";

interface MatchResultFormProps {
  eventType: EventType;
  onSave: () => void;
  onCancel: () => void;
}

export function MatchResultForm({ eventType, onSave, onCancel }: MatchResultFormProps) {
  return (
    <div>
      {eventType === "single" && <SingleMatchForm onSave={onSave} onCancel={onCancel} />}
      {eventType === "team" && <TeamMatchForm onSave={onSave} onCancel={onCancel} />}
      {eventType === "doubles" && <DoublesMatchForm onSave={onSave} onCancel={onCancel} />}
    </div>
  );
}
