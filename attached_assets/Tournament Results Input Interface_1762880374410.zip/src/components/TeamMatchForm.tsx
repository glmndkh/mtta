import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card } from "./ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Save, X, Users } from "lucide-react";

interface TeamMatchFormProps {
  onSave: () => void;
  onCancel: () => void;
}

interface SubMatch {
  type: string;
  teamAPlayer?: string;
  teamBPlayer?: string;
  sets: { teamA: string; teamB: string }[];
}

export function TeamMatchForm({ onSave, onCancel }: TeamMatchFormProps) {
  const teamAMembers = [
    { id: "1", name: "Б. Энхболд", photo: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=100" },
    { id: "2", name: "Г. Мөнхбат", photo: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100" },
    { id: "3", name: "Н. Түвшинбаяр", photo: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100" },
  ];

  const teamBMembers = [
    { id: "4", name: "Д. Бат-Эрдэнэ", photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100" },
    { id: "5", name: "Ч. Өнөрбаяр", photo: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100" },
    { id: "6", name: "Л. Ганзориг", photo: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=100" },
  ];

  const [subMatches, setSubMatches] = useState<SubMatch[]>([
    {
      type: "Ганцаарчилсан 1",
      teamAPlayer: "",
      teamBPlayer: "",
      sets: [{ teamA: "", teamB: "" }, { teamA: "", teamB: "" }, { teamA: "", teamB: "" }],
    },
    {
      type: "Ганцаарчилсан 2",
      teamAPlayer: "",
      teamBPlayer: "",
      sets: [{ teamA: "", teamB: "" }, { teamA: "", teamB: "" }, { teamA: "", teamB: "" }],
    },
    {
      type: "Хос",
      sets: [{ teamA: "", teamB: "" }, { teamA: "", teamB: "" }, { teamA: "", teamB: "" }],
    },
    {
      type: "Ганцаарчилсан 3",
      teamAPlayer: "",
      teamBPlayer: "",
      sets: [{ teamA: "", teamB: "" }, { teamA: "", teamB: "" }, { teamA: "", teamB: "" }],
    },
  ]);

  const updateSubMatchSet = (matchIndex: number, setIndex: number, team: "teamA" | "teamB", value: string) => {
    const newSubMatches = [...subMatches];
    newSubMatches[matchIndex].sets[setIndex][team] = value;
    setSubMatches(newSubMatches);
  };

  const updateSubMatchPlayer = (matchIndex: number, team: "teamAPlayer" | "teamBPlayer", value: string) => {
    const newSubMatches = [...subMatches];
    newSubMatches[matchIndex][team] = value;
    setSubMatches(newSubMatches);
  };

  return (
    <div className="space-y-6">
      {/* Team Headers */}
      <div className="grid grid-cols-2 gap-4">
        <Card className="p-4 border-emerald-200 bg-gradient-to-br from-emerald-50 to-white">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-gray-900">Баг А</h3>
              <p className="text-gray-600">Улаанбаатар клуб</p>
            </div>
          </div>
          <div className="space-y-2">
            {teamAMembers.map((member) => (
              <div key={member.id} className="flex items-center gap-2 p-2 bg-white rounded-lg">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={member.photo} />
                  <AvatarFallback>{member.name[0]}</AvatarFallback>
                </Avatar>
                <span className="text-gray-800">{member.name}</span>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-4 border-gray-200 bg-gradient-to-br from-gray-50 to-white">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-gray-700 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-gray-900">Баг Б</h3>
              <p className="text-gray-600">Монгол Алтан клуб</p>
            </div>
          </div>
          <div className="space-y-2">
            {teamBMembers.map((member) => (
              <div key={member.id} className="flex items-center gap-2 p-2 bg-white rounded-lg">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={member.photo} />
                  <AvatarFallback>{member.name[0]}</AvatarFallback>
                </Avatar>
                <span className="text-gray-800">{member.name}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Sub Matches */}
      <div className="space-y-4">
        <h3 className="text-gray-700">Дэд тоглолтууд</h3>
        {subMatches.map((subMatch, matchIndex) => (
          <Card key={matchIndex} className="p-4 bg-gray-50">
            <h4 className="text-gray-800 mb-3">{subMatch.type}</h4>
            {subMatch.type !== "Хос" && (
              <div className="grid grid-cols-2 gap-3 mb-3">
                <Select
                  value={subMatch.teamAPlayer}
                  onValueChange={(value) => updateSubMatchPlayer(matchIndex, "teamAPlayer", value)}
                >
                  <SelectTrigger className="bg-white">
                    <SelectValue placeholder="Баг А - Тоглогч" />
                  </SelectTrigger>
                  <SelectContent>
                    {teamAMembers.map((member) => (
                      <SelectItem key={member.id} value={member.id}>
                        {member.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select
                  value={subMatch.teamBPlayer}
                  onValueChange={(value) => updateSubMatchPlayer(matchIndex, "teamBPlayer", value)}
                >
                  <SelectTrigger className="bg-white">
                    <SelectValue placeholder="Баг Б - Тоглогч" />
                  </SelectTrigger>
                  <SelectContent>
                    {teamBMembers.map((member) => (
                      <SelectItem key={member.id} value={member.id}>
                        {member.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="grid grid-cols-3 gap-2">
              {subMatch.sets.map((set, setIndex) => (
                <div key={setIndex} className="bg-white p-3 rounded-lg">
                  <div className="text-gray-500 mb-2">Сет {setIndex + 1}</div>
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      value={set.teamA}
                      onChange={(e) => updateSubMatchSet(matchIndex, setIndex, "teamA", e.target.value)}
                      className="w-14 h-9 text-center"
                      placeholder="0"
                      min="0"
                    />
                    <span className="text-gray-400">:</span>
                    <Input
                      type="number"
                      value={set.teamB}
                      onChange={(e) => updateSubMatchSet(matchIndex, setIndex, "teamB", e.target.value)}
                      className="w-14 h-9 text-center"
                      placeholder="0"
                      min="0"
                    />
                  </div>
                </div>
              ))}
            </div>
          </Card>
        ))}
      </div>

      {/* Actions */}
      <div className="flex justify-end gap-3 pt-4 border-t">
        <Button variant="outline" onClick={onCancel}>
          <X className="w-4 h-4 mr-2" />
          Цуцлах
        </Button>
        <Button onClick={onSave} className="bg-emerald-600 hover:bg-emerald-700">
          <Save className="w-4 h-4 mr-2" />
          Үр дүн хадгалах
        </Button>
      </div>
    </div>
  );
}
