import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card } from "./ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Plus, Save, X, Trophy } from "lucide-react";

interface SinglesMatchInputProps {
  onSave: () => void;
  onCancel: () => void;
}

interface SetScore {
  player1: string;
  player2: string;
}

export function SinglesMatchInput({ onSave, onCancel }: SinglesMatchInputProps) {
  const [sets, setSets] = useState<SetScore[]>([
    { player1: "", player2: "" },
    { player1: "", player2: "" },
    { player1: "", player2: "" },
  ]);

  const addSet = () => {
    if (sets.length < 7) {
      setSets([...sets, { player1: "", player2: "" }]);
    }
  };

  const updateSet = (index: number, player: "player1" | "player2", value: string) => {
    const newSets = [...sets];
    newSets[index][player] = value;
    setSets(newSets);
  };

  const calculateWinner = () => {
    let player1Wins = 0;
    let player2Wins = 0;

    sets.forEach((set) => {
      const p1Score = parseInt(set.player1) || 0;
      const p2Score = parseInt(set.player2) || 0;
      if (p1Score > p2Score && set.player1 && set.player2) player1Wins++;
      if (p2Score > p1Score && set.player1 && set.player2) player2Wins++;
    });

    if (player1Wins >= 3 && player1Wins > player2Wins) return "player1";
    if (player2Wins >= 3 && player2Wins > player1Wins) return "player2";
    return null;
  };

  const winner = calculateWinner();

  const player1 = {
    name: "Б. Энхболд",
    club: "Улаанбаатар клуб",
    photo: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=200",
  };

  const player2 = {
    name: "Д. Бат-Эрдэнэ",
    club: "Монгол Алтан клуб",
    photo: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200",
  };

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-[1fr_auto_1fr] gap-10">
        {/* Player 1 */}
        <Card
          className={`p-6 transition-all ${
            winner === "player1"
              ? "border-2 border-emerald-600 bg-gradient-to-br from-emerald-50 to-white shadow-xl"
              : "bg-gray-50 border border-gray-200"
          }`}
        >
          <div className="flex flex-col items-center text-center gap-4">
            <div className="relative">
              <Avatar className="w-28 h-28 border-4 border-white shadow-lg">
                <AvatarImage src={player1.photo} />
                <AvatarFallback>{player1.name[0]}</AvatarFallback>
              </Avatar>
              {winner === "player1" && (
                <div className="absolute -top-2 -right-2 w-10 h-10 bg-emerald-600 rounded-full flex items-center justify-center shadow-lg">
                  <Trophy className="w-5 h-5 text-white" />
                </div>
              )}
            </div>
            <div>
              <h3 className="text-gray-900 mb-1">{player1.name}</h3>
              <p className="text-gray-600">{player1.club}</p>
            </div>
          </div>
        </Card>

        {/* Score Input */}
        <div className="min-w-[280px] space-y-4">
          <div className="text-center mb-6 p-4 bg-gray-50 rounded-xl">
            <div className="text-gray-600 mb-2">Сетийн оноо</div>
            <div className="flex justify-center items-center gap-4">
              <div className="text-3xl text-emerald-700">
                {sets.filter((s) => parseInt(s.player1) > parseInt(s.player2) && s.player1 && s.player2).length}
              </div>
              <div className="text-3xl text-gray-400">-</div>
              <div className="text-3xl text-emerald-700">
                {sets.filter((s) => parseInt(s.player2) > parseInt(s.player1) && s.player1 && s.player2).length}
              </div>
            </div>
          </div>

          {sets.map((set, index) => (
            <Card key={index} className="p-4 bg-white border-gray-200 shadow-sm">
              <div className="flex items-center gap-3">
                <span className="text-gray-600 min-w-[60px]">Сет {index + 1}</span>
                <Input
                  type="number"
                  value={set.player1}
                  onChange={(e) => updateSet(index, "player1", e.target.value)}
                  className="w-20 h-12 text-center text-lg border-gray-300"
                  placeholder="0"
                  min="0"
                />
                <span className="text-gray-400">:</span>
                <Input
                  type="number"
                  value={set.player2}
                  onChange={(e) => updateSet(index, "player2", e.target.value)}
                  className="w-20 h-12 text-center text-lg border-gray-300"
                  placeholder="0"
                  min="0"
                />
              </div>
            </Card>
          ))}

          {sets.length < 7 && (
            <Button
              variant="outline"
              onClick={addSet}
              className="w-full border-emerald-300 text-emerald-700 hover:bg-emerald-50 h-12"
            >
              <Plus className="w-4 h-4 mr-2" />
              Сет нэмэх
            </Button>
          )}
        </div>

        {/* Player 2 */}
        <Card
          className={`p-6 transition-all ${
            winner === "player2"
              ? "border-2 border-emerald-600 bg-gradient-to-br from-emerald-50 to-white shadow-xl"
              : "bg-gray-50 border border-gray-200"
          }`}
        >
          <div className="flex flex-col items-center text-center gap-4">
            <div className="relative">
              <Avatar className="w-28 h-28 border-4 border-white shadow-lg">
                <AvatarImage src={player2.photo} />
                <AvatarFallback>{player2.name[0]}</AvatarFallback>
              </Avatar>
              {winner === "player2" && (
                <div className="absolute -top-2 -right-2 w-10 h-10 bg-emerald-600 rounded-full flex items-center justify-center shadow-lg">
                  <Trophy className="w-5 h-5 text-white" />
                </div>
              )}
            </div>
            <div>
              <h3 className="text-gray-900 mb-1">{player2.name}</h3>
              <p className="text-gray-600">{player2.club}</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Actions */}
      <div className="flex justify-end gap-3 pt-6 border-t border-gray-200">
        <Button variant="outline" onClick={onCancel} className="h-12 px-6 border-gray-300">
          <X className="w-4 h-4 mr-2" />
          Цуцлах
        </Button>
        <Button onClick={onSave} className="bg-emerald-600 hover:bg-emerald-700 h-12 px-8 shadow-lg">
          <Save className="w-4 h-4 mr-2" />
          Үр дүн хадгалах
        </Button>
      </div>
    </div>
  );
}
