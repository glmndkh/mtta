import { useState } from "react";
import { PlayerCard } from "./PlayerCard";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Plus, Save } from "lucide-react";
import { Card } from "./ui/card";

interface SingleMatchInputProps {
  onSave: () => void;
  roundType: string;
}

interface SetScore {
  player1: string;
  player2: string;
}

export function SingleMatchInput({ onSave, roundType }: SingleMatchInputProps) {
  const [sets, setSets] = useState<SetScore[]>([
    { player1: "", player2: "" },
    { player1: "", player2: "" },
    { player1: "", player2: "" },
  ]);

  const addSet = () => {
    if (sets.length < 7) {
      setSets([...sets, { player1: "", player2: "" }]);
    }
  };

  const updateSet = (index: number, player: "player1" | "player2", value: string) => {
    const newSets = [...sets];
    newSets[index][player] = value;
    setSets(newSets);
  };

  const calculateWinner = () => {
    let player1Wins = 0;
    let player2Wins = 0;

    sets.forEach((set) => {
      const p1Score = parseInt(set.player1) || 0;
      const p2Score = parseInt(set.player2) || 0;
      if (p1Score > p2Score) player1Wins++;
      if (p2Score > p1Score) player2Wins++;
    });

    if (player1Wins > player2Wins && player1Wins >= 3) return "player1";
    if (player2Wins > player1Wins && player2Wins >= 3) return "player2";
    return null;
  };

  const winner = calculateWinner();

  const player1 = {
    name: "Б. Энхболд",
    club: "Улаанбаатар клуб",
    photo: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=200&h=200&fit=crop",
  };

  const player2 = {
    name: "Д. Бат-Эрдэнэ",
    club: "Монгол Алтан клуб",
    photo: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&h=200&fit=crop",
  };

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-[1fr_auto_1fr] gap-8 items-start">
        <PlayerCard
          player={player1}
          isWinner={winner === "player1"}
          position="left"
        />

        <div className="flex flex-col gap-4 min-w-[280px]">
          <div className="text-center mb-4">
            <div className="text-gray-500 mb-2">Сетийн оноо</div>
            <div className="flex justify-center gap-4">
              <div className="text-3xl text-emerald-600">{sets.filter((s, i) => parseInt(s.player1) > parseInt(s.player2) && s.player1 && s.player2).length}</div>
              <div className="text-3xl text-gray-300">-</div>
              <div className="text-3xl text-emerald-600">{sets.filter((s, i) => parseInt(s.player2) > parseInt(s.player1) && s.player1 && s.player2).length}</div>
            </div>
          </div>

          {sets.map((set, index) => (
            <Card key={index} className="p-4 bg-gray-50 border-gray-200">
              <div className="flex items-center gap-3">
                <div className="text-gray-500 min-w-[60px]">Сет {index + 1}</div>
                <Input
                  type="number"
                  value={set.player1}
                  onChange={(e) => updateSet(index, "player1", e.target.value)}
                  className="w-20 h-12 text-center border-gray-300"
                  placeholder="0"
                  min="0"
                />
                <div className="text-gray-400">:</div>
                <Input
                  type="number"
                  value={set.player2}
                  onChange={(e) => updateSet(index, "player2", e.target.value)}
                  className="w-20 h-12 text-center border-gray-300"
                  placeholder="0"
                  min="0"
                />
              </div>
            </Card>
          ))}

          {sets.length < 7 && (
            <Button
              variant="outline"
              onClick={addSet}
              className="w-full border-emerald-200 text-emerald-700 hover:bg-emerald-50"
            >
              <Plus className="w-4 h-4 mr-2" />
              Сет нэмэх
            </Button>
          )}
        </div>

        <PlayerCard
          player={player2}
          isWinner={winner === "player2"}
          position="right"
        />
      </div>

      <div className="flex justify-center pt-4">
        <Button
          onClick={onSave}
          className="bg-emerald-600 hover:bg-emerald-700 px-12 h-14 shadow-lg"
        >
          <Save className="w-5 h-5 mr-2" />
          Үр дүн хадгалах
        </Button>
      </div>
    </div>
  );
}
