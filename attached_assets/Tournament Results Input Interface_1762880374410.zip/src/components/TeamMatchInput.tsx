import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card } from "./ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Save, X, Users } from "lucide-react";

interface TeamMatchInputProps {
  onSave: () => void;
  onCancel: () => void;
}

interface SubMatch {
  type: string;
  teamAPlayer?: string;
  teamBPlayer?: string;
  sets: { teamA: string; teamB: string }[];
}

export function TeamMatchInput({ onSave, onCancel }: TeamMatchInputProps) {
  const teamAMembers = [
    { id: "1", name: "Б. Энхболд", photo: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=100" },
    { id: "2", name: "Г. Мөнхбат", photo: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100" },
    { id: "3", name: "Н. Түвшинбаяр", photo: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100" },
  ];

  const teamBMembers = [
    { id: "4", name: "Д. Бат-Эрдэнэ", photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100" },
    { id: "5", name: "Ч. Өнөрбаяр", photo: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100" },
    { id: "6", name: "Л. Ганзориг", photo: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=100" },
  ];

  const [subMatches, setSubMatches] = useState<SubMatch[]>([
    {
      type: "Ганцаарчилсан 1",
      teamAPlayer: "",
      teamBPlayer: "",
      sets: [{ teamA: "", teamB: "" }, { teamA: "", teamB: "" }, { teamA: "", teamB: "" }],
    },
    {
      type: "Ганцаарчилсан 2",
      teamAPlayer: "",
      teamBPlayer: "",
      sets: [{ teamA: "", teamB: "" }, { teamA: "", teamB: "" }, { teamA: "", teamB: "" }],
    },
    {
      type: "Хос",
      sets: [{ teamA: "", teamB: "" }, { teamA: "", teamB: "" }, { teamA: "", teamB: "" }],
    },
    {
      type: "Ганцаарчилсан 3",
      teamAPlayer: "",
      teamBPlayer: "",
      sets: [{ teamA: "", teamB: "" }, { teamA: "", teamB: "" }, { teamA: "", teamB: "" }],
    },
  ]);

  const updateSubMatchSet = (matchIndex: number, setIndex: number, team: "teamA" | "teamB", value: string) => {
    const newSubMatches = [...subMatches];
    newSubMatches[matchIndex].sets[setIndex][team] = value;
    setSubMatches(newSubMatches);
  };

  const updateSubMatchPlayer = (matchIndex: number, team: "teamAPlayer" | "teamBPlayer", value: string) => {
    const newSubMatches = [...subMatches];
    newSubMatches[matchIndex][team] = value;
    setSubMatches(newSubMatches);
  };

  return (
    <div className="space-y-8">
      {/* Team Headers */}
      <div className="grid grid-cols-2 gap-6">
        <Card className="p-5 border-emerald-300 bg-gradient-to-br from-emerald-50 to-white">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-11 h-11 bg-emerald-600 rounded-xl flex items-center justify-center shadow-md">
              <Users className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-gray-900">Баг А</h3>
              <p className="text-gray-600">Улаанбаатар клуб</p>
            </div>
          </div>
          <div className="space-y-2">
            {teamAMembers.map((member) => (
              <div key={member.id} className="flex items-center gap-3 p-3 bg-white rounded-lg shadow-sm">
                <Avatar className="w-10 h-10 border-2 border-white shadow-sm">
                  <AvatarImage src={member.photo} />
                  <AvatarFallback>{member.name[0]}</AvatarFallback>
                </Avatar>
                <span className="text-gray-800">{member.name}</span>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-5 border-gray-300 bg-gradient-to-br from-gray-50 to-white">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-11 h-11 bg-gray-700 rounded-xl flex items-center justify-center shadow-md">
              <Users className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-gray-900">Баг Б</h3>
              <p className="text-gray-600">Монгол Алтан клуб</p>
            </div>
          </div>
          <div className="space-y-2">
            {teamBMembers.map((member) => (
              <div key={member.id} className="flex items-center gap-3 p-3 bg-white rounded-lg shadow-sm">
                <Avatar className="w-10 h-10 border-2 border-white shadow-sm">
                  <AvatarImage src={member.photo} />
                  <AvatarFallback>{member.name[0]}</AvatarFallback>
                </Avatar>
                <span className="text-gray-800">{member.name}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Sub Matches */}
      <div className="space-y-5">
        <h3 className="text-gray-800">Дэд тоглолтууд</h3>
        {subMatches.map((subMatch, matchIndex) => (
          <Card key={matchIndex} className="p-5 bg-gray-50 border-gray-200">
            <h4 className="text-gray-800 mb-4">{subMatch.type}</h4>
            {subMatch.type !== "Хос" && (
              <div className="grid grid-cols-2 gap-4 mb-4">
                <Select
                  value={subMatch.teamAPlayer}
                  onValueChange={(value) => updateSubMatchPlayer(matchIndex, "teamAPlayer", value)}
                >
                  <SelectTrigger className="bg-white h-11 border-gray-300">
                    <SelectValue placeholder="Баг А - Тоглогч сонгох" />
                  </SelectTrigger>
                  <SelectContent>
                    {teamAMembers.map((member) => (
                      <SelectItem key={member.id} value={member.id}>
                        {member.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select
                  value={subMatch.teamBPlayer}
                  onValueChange={(value) => updateSubMatchPlayer(matchIndex, "teamBPlayer", value)}
                >
                  <SelectTrigger className="bg-white h-11 border-gray-300">
                    <SelectValue placeholder="Баг Б - Тоглогч сонгох" />
                  </SelectTrigger>
                  <SelectContent>
                    {teamBMembers.map((member) => (
                      <SelectItem key={member.id} value={member.id}>
                        {member.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="grid grid-cols-3 gap-3">
              {subMatch.sets.map((set, setIndex) => (
                <div key={setIndex} className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
                  <div className="text-gray-600 mb-3">Сет {setIndex + 1}</div>
                  <div className="flex items-center gap-2">
                    <Input
                      type="number"
                      value={set.teamA}
                      onChange={(e) => updateSubMatchSet(matchIndex, setIndex, "teamA", e.target.value)}
                      className="w-16 h-11 text-center border-gray-300"
                      placeholder="0"
                      min="0"
                    />
                    <span className="text-gray-400">:</span>
                    <Input
                      type="number"
                      value={set.teamB}
                      onChange={(e) => updateSubMatchSet(matchIndex, setIndex, "teamB", e.target.value)}
                      className="w-16 h-11 text-center border-gray-300"
                      placeholder="0"
                      min="0"
                    />
                  </div>
                </div>
              ))}
            </div>
          </Card>
        ))}
      </div>

      {/* Actions */}
      <div className="flex justify-end gap-3 pt-6 border-t border-gray-200">
        <Button variant="outline" onClick={onCancel} className="h-12 px-6 border-gray-300">
          <X className="w-4 h-4 mr-2" />
          Цуцлах
        </Button>
        <Button onClick={onSave} className="bg-emerald-600 hover:bg-emerald-700 h-12 px-8 shadow-lg">
          <Save className="w-4 h-4 mr-2" />
          Үр дүн хадгалах
        </Button>
      </div>
    </div>
  );
}
