import { useState } from "react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Table2, Trophy, Users, UserSquare2, Grid3x3, Info } from "lucide-react";
import { TournamentConfig, EventType, Category } from "../App";
import { Alert, AlertDescription } from "./ui/alert";

interface FormatSelectionProps {
  onSelect: (config: TournamentConfig) => void;
}

export function FormatSelection({ onSelect }: FormatSelectionProps) {
  const [selectedFormat, setSelectedFormat] = useState<"group" | "playoff" | null>(null);
  const [selectedEventType, setSelectedEventType] = useState<EventType>("singles");
  const [selectedCategory, setSelectedCategory] = useState<Category>("men");

  const handleContinue = () => {
    if (selectedFormat) {
      onSelect({
        format: selectedFormat,
        eventType: selectedEventType,
        category: selectedCategory,
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-emerald-50/30 to-gray-100 flex items-center justify-center p-8">
      <div className="max-w-6xl w-full">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-emerald-600 to-emerald-700 rounded-3xl shadow-2xl mb-6">
            <Trophy className="w-11 h-11 text-white" />
          </div>
          <h1 className="text-gray-900 mb-3">Тэмцээний удирдлагын систем</h1>
          <p className="text-gray-600">Ширээний теннисний үр дүн оруулах хэсэг</p>
        </div>

        {/* Format Selection */}
        <Card className="p-8 mb-8 bg-white shadow-2xl border-0">
          <h2 className="text-gray-900 mb-6 text-center">Та ямар хэлбэрийг үүсгэх вэ?</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {/* Group Stage Card */}
            <Card
              onClick={() => setSelectedFormat("group")}
              className={`group cursor-pointer transition-all duration-300 border-2 overflow-hidden ${
                selectedFormat === "group"
                  ? "border-emerald-600 shadow-2xl scale-105 bg-gradient-to-br from-emerald-50 to-white"
                  : "border-gray-200 hover:border-emerald-400 hover:shadow-xl bg-white"
              }`}
            >
              <div className="p-8">
                <div
                  className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-6 transition-all ${
                    selectedFormat === "group"
                      ? "bg-emerald-600 shadow-lg scale-110"
                      : "bg-gray-100 group-hover:bg-emerald-100"
                  }`}
                >
                  <Table2
                    className={`w-8 h-8 ${
                      selectedFormat === "group" ? "text-white" : "text-gray-600 group-hover:text-emerald-600"
                    }`}
                  />
                </div>
                <h3 className="text-gray-900 mb-3">Шигшээ хүртэлх хэсэг</h3>
                <p className="text-gray-600 mb-6">
                  Бүлгийн тоглолт, хүснэгт систем. Тоглогчид эрэмбийн хүснэгтээр ялгаж шигших тоглогчдыг тодорхойлно.
                </p>
                <ul className="space-y-2 text-gray-600">
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full"></div>
                    Бүлгийн байрлал хүснэгт
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full"></div>
                    MP, W, L, SD, PTS тооцоолол
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full"></div>
                    Шигшсэн статус
                  </li>
                </ul>
              </div>
              {selectedFormat === "group" && (
                <div className="h-2 bg-gradient-to-r from-emerald-600 to-emerald-700"></div>
              )}
            </Card>

            {/* Playoff Card */}
            <Card
              onClick={() => setSelectedFormat("playoff")}
              className={`group cursor-pointer transition-all duration-300 border-2 overflow-hidden ${
                selectedFormat === "playoff"
                  ? "border-emerald-600 shadow-2xl scale-105 bg-gradient-to-br from-emerald-50 to-white"
                  : "border-gray-200 hover:border-emerald-400 hover:shadow-xl bg-white"
              }`}
            >
              <div className="p-8">
                <div
                  className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-6 transition-all ${
                    selectedFormat === "playoff"
                      ? "bg-emerald-600 shadow-lg scale-110"
                      : "bg-gray-100 group-hover:bg-emerald-100"
                  }`}
                >
                  <Grid3x3
                    className={`w-8 h-8 ${
                      selectedFormat === "playoff" ? "text-white" : "text-gray-600 group-hover:text-emerald-600"
                    }`}
                  />
                </div>
                <h3 className="text-gray-900 mb-3">Шууд шат / Playoff</h3>
                <p className="text-gray-600 mb-6">
                  Bracket тогтолцоо. Ялагдсан тоглогч шууд хасагдах систем. Quarter → Semi → Final.
                </p>
                <ul className="space-y-2 text-gray-600">
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full"></div>
                    Knockout bracket
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full"></div>
                    Quarter / Semi / Final
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full"></div>
                    3-р байрны тоглолт
                  </li>
                </ul>
              </div>
              {selectedFormat === "playoff" && (
                <div className="h-2 bg-gradient-to-r from-emerald-600 to-emerald-700"></div>
              )}
            </Card>
          </div>

          {/* Event Type Selection */}
          {selectedFormat && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="h-px bg-gray-200 my-8"></div>
              
              <div>
                <h3 className="text-gray-800 mb-4">Тэмцээний төрөл</h3>
                <div className="grid grid-cols-3 gap-4">
                  <Button
                    variant={selectedEventType === "singles" ? "default" : "outline"}
                    onClick={() => setSelectedEventType("singles")}
                    className={`h-20 flex-col gap-2 transition-all ${
                      selectedEventType === "singles"
                        ? "bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg"
                        : "border-gray-300 hover:border-emerald-500 hover:bg-emerald-50"
                    }`}
                  >
                    <UserSquare2 className="w-7 h-7" />
                    <span>Ганцаарчилсан</span>
                  </Button>

                  <Button
                    variant={selectedEventType === "doubles" ? "default" : "outline"}
                    onClick={() => setSelectedEventType("doubles")}
                    className={`h-20 flex-col gap-2 transition-all ${
                      selectedEventType === "doubles"
                        ? "bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg"
                        : "border-gray-300 hover:border-emerald-500 hover:bg-emerald-50"
                    }`}
                  >
                    <Users className="w-7 h-7" />
                    <span>Хос</span>
                  </Button>

                  <Button
                    variant={selectedEventType === "team" ? "default" : "outline"}
                    onClick={() => setSelectedEventType("team")}
                    className={`h-20 flex-col gap-2 transition-all ${
                      selectedEventType === "team"
                        ? "bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg"
                        : "border-gray-300 hover:border-emerald-500 hover:bg-emerald-50"
                    }`}
                  >
                    <Grid3x3 className="w-7 h-7" />
                    <span>Багийн</span>
                  </Button>
                </div>
              </div>

              {/* Doubles Warning */}
              {selectedEventType === "doubles" && selectedFormat === "group" && (
                <Alert className="bg-amber-50 border-amber-300 border-2">
                  <Info className="h-5 w-5 text-amber-700" />
                  <AlertDescription className="text-amber-900">
                    <span>
                      Анхаар: Хосын төрөл ихэвчлэн шууд шатанд ордог. Та "Шууд шат / Playoff" хэлбэрийг сонгохыг зөвлөж байна.
                    </span>
                  </AlertDescription>
                </Alert>
              )}

              {/* Category Selection */}
              <div>
                <h3 className="text-gray-800 mb-4">Ангилал</h3>
                <div className="grid grid-cols-4 gap-3">
                  {[
                    { value: "men", label: "Эрэгтэй", color: "blue" },
                    { value: "women", label: "Эмэгтэй", color: "pink" },
                    { value: "u15", label: "U15", color: "purple" },
                    { value: "veteran", label: "Ахмадууд", color: "orange" },
                  ].map((cat) => (
                    <Badge
                      key={cat.value}
                      variant={selectedCategory === cat.value ? "default" : "outline"}
                      onClick={() => setSelectedCategory(cat.value as Category)}
                      className={`cursor-pointer py-3 px-4 justify-center transition-all ${
                        selectedCategory === cat.value
                          ? "bg-emerald-600 text-white hover:bg-emerald-700 shadow-md"
                          : "border-gray-300 text-gray-700 hover:border-emerald-500 hover:bg-emerald-50"
                      }`}
                    >
                      {cat.label}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Continue Button */}
              <div className="flex justify-center pt-4">
                <Button
                  onClick={handleContinue}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white px-12 h-14 shadow-xl"
                >
                  <Trophy className="w-5 h-5 mr-2" />
                  Үргэлжлүүлэх
                </Button>
              </div>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
