import { useState } from "react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { Trophy, Users, Grid3x3, Zap, Info } from "lucide-react";
import { EventType } from "../App";
import { Alert, AlertDescription } from "./ui/alert";

interface ModeSelectionProps {
  onModeSelect: (mode: "group" | "playoff", eventType: EventType) => void;
}

export function ModeSelection({ onModeSelect }: ModeSelectionProps) {
  const [eventType, setEventType] = useState<EventType>("single");

  const handleGroupStage = () => {
    onModeSelect("group", eventType);
  };

  const handlePlayOff = () => {
    onModeSelect("playoff", eventType);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-8">
      <div className="max-w-5xl w-full">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-emerald-600 to-emerald-700 rounded-2xl shadow-2xl mb-6">
            <Trophy className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-gray-900 mb-4">Ширээний теннисний тэмцээн</h1>
          <p className="text-gray-600">Тэмцээний удирдлагын систем 2025</p>
        </div>

        {/* Event Type Selection */}
        <Card className="p-8 mb-8 bg-white shadow-xl border-gray-200">
          <h2 className="text-gray-800 mb-6 text-center">Тэмцээний төрөл сонгох</h2>
          <div className="grid grid-cols-3 gap-4">
            <Button
              variant={eventType === "single" ? "default" : "outline"}
              onClick={() => setEventType("single")}
              className={`h-24 flex-col gap-2 ${
                eventType === "single"
                  ? "bg-emerald-600 hover:bg-emerald-700 text-white"
                  : "border-gray-300 hover:border-emerald-500"
              }`}
            >
              <Users className="w-8 h-8" />
              <span>Ганцаарчилсан</span>
            </Button>

            <Button
              variant={eventType === "team" ? "default" : "outline"}
              onClick={() => setEventType("team")}
              className={`h-24 flex-col gap-2 ${
                eventType === "team"
                  ? "bg-emerald-600 hover:bg-emerald-700 text-white"
                  : "border-gray-300 hover:border-emerald-500"
              }`}
            >
              <Grid3x3 className="w-8 h-8" />
              <span>Баг</span>
            </Button>

            <Button
              variant={eventType === "doubles" ? "default" : "outline"}
              onClick={() => setEventType("doubles")}
              className={`h-24 flex-col gap-2 ${
                eventType === "doubles"
                  ? "bg-emerald-600 hover:bg-emerald-700 text-white"
                  : "border-gray-300 hover:border-emerald-500"
              }`}
            >
              <Users className="w-8 h-8" />
              <span>Хос</span>
            </Button>
          </div>
        </Card>

        {/* Doubles Info */}
        {eventType === "doubles" && (
          <Alert className="mb-8 bg-amber-50 border-amber-200">
            <Info className="h-5 w-5 text-amber-600" />
            <AlertDescription className="text-amber-800">
              Хосын төрөл ихэнхдээ шууд шатанд тоглодог. Та шууд шатыг сонгохыг зөвлөж байна.
            </AlertDescription>
          </Alert>
        )}

        {/* Mode Selection */}
        <div>
          <h2 className="text-gray-800 mb-6 text-center">Та тэмцээний тоглолтын хэлбэрийг сонгоно уу</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Group Stage */}
            <Card
              className="group cursor-pointer transition-all duration-300 hover:shadow-2xl hover:scale-105 border-2 border-gray-200 hover:border-emerald-500 bg-white overflow-hidden"
              onClick={handleGroupStage}
            >
              <div className="p-8">
                <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-lg">
                  <Grid3x3 className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-gray-900 mb-3">Шигшээ хүртэлх хэсгийн тоглолт</h3>
                <p className="text-gray-600 mb-6">
                  Бүлгийн тоглолт. Тоглогчид/багууд бүлэгт хуваагдан тоглоно.
                </p>
                <ul className="space-y-2 text-gray-600">
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full"></div>
                    Бүлгийн хүснэгт
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full"></div>
                    Тоглолтын үр дүн оруулах
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full"></div>
                    Шигшсэн тоглогчид шууд шатад
                  </li>
                </ul>
              </div>
              <div className="h-2 bg-gradient-to-r from-emerald-500 to-emerald-600"></div>
            </Card>

            {/* Play-Off */}
            <Card
              className="group cursor-pointer transition-all duration-300 hover:shadow-2xl hover:scale-105 border-2 border-gray-200 hover:border-emerald-500 bg-white overflow-hidden"
              onClick={handlePlayOff}
            >
              <div className="p-8">
                <div className="w-16 h-16 bg-gradient-to-br from-emerald-600 to-emerald-700 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform shadow-lg">
                  <Zap className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-gray-900 mb-3">Шууд шат</h3>
                <p className="text-gray-600 mb-6">
                  Play-off систем. Ялагдсан тоглогч хасагдана.
                </p>
                <ul className="space-y-2 text-gray-600">
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full"></div>
                    Bracket тогтолцоо
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full"></div>
                    Quarter / Semi / Final
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full"></div>
                    Шууд тулалдаан
                  </li>
                </ul>
              </div>
              <div className="h-2 bg-gradient-to-r from-emerald-600 to-emerald-700"></div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
