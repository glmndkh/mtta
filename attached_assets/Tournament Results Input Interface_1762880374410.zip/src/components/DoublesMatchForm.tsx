import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card } from "./ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Save, X } from "lucide-react";

interface DoublesMatchFormProps {
  onSave: () => void;
  onCancel: () => void;
}

interface SetScore {
  teamA: string;
  teamB: string;
}

export function DoublesMatchForm({ onSave, onCancel }: DoublesMatchFormProps) {
  const [sets, setSets] = useState<SetScore[]>([
    { teamA: "", teamB: "" },
    { teamA: "", teamB: "" },
    { teamA: "", teamB: "" },
  ]);

  const updateSet = (index: number, team: "teamA" | "teamB", value: string) => {
    const newSets = [...sets];
    newSets[index][team] = value;
    setSets(newSets);
  };

  const calculateWinner = () => {
    let teamAWins = 0;
    let teamBWins = 0;

    sets.forEach((set) => {
      const aScore = parseInt(set.teamA) || 0;
      const bScore = parseInt(set.teamB) || 0;
      if (aScore > bScore) teamAWins++;
      if (bScore > aScore) teamBWins++;
    });

    if (teamAWins > teamBWins && teamAWins >= 3) return "teamA";
    if (teamBWins > teamAWins && teamBWins >= 3) return "teamB";
    return null;
  };

  const winner = calculateWinner();

  const teamA = {
    player1: {
      name: "Б. Энхболд",
      photo: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=200",
    },
    player2: {
      name: "Г. Мөнхбат",
      photo: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200",
    },
    club: "Улаанбаатар клуб",
  };

  const teamB = {
    player1: {
      name: "Д. Бат-Эрдэнэ",
      photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200",
    },
    player2: {
      name: "Ч. Өнөрбаяр",
      photo: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200",
    },
    club: "Монгол Алтан клуб",
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-[1fr_auto_1fr] gap-8">
        {/* Team A */}
        <Card className={`p-6 ${winner === "teamA" ? "border-2 border-emerald-500 bg-emerald-50" : "bg-gray-50"}`}>
          <div className="text-center mb-4">
            <div className="inline-block px-3 py-1 bg-emerald-600 text-white rounded-full mb-3">
              Баг А
            </div>
            <p className="text-gray-600">{teamA.club}</p>
          </div>
          <div className="space-y-3">
            <div className="flex items-center gap-3 p-3 bg-white rounded-lg">
              <Avatar className="w-12 h-12">
                <AvatarImage src={teamA.player1.photo} />
                <AvatarFallback>{teamA.player1.name[0]}</AvatarFallback>
              </Avatar>
              <div>
                <div className="text-gray-800">{teamA.player1.name}</div>
                <div className="text-gray-500">Тоглогч 1</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-white rounded-lg">
              <Avatar className="w-12 h-12">
                <AvatarImage src={teamA.player2.photo} />
                <AvatarFallback>{teamA.player2.name[0]}</AvatarFallback>
              </Avatar>
              <div>
                <div className="text-gray-800">{teamA.player2.name}</div>
                <div className="text-gray-500">Тоглогч 2</div>
              </div>
            </div>
          </div>
        </Card>

        {/* Score Input */}
        <div className="min-w-[240px] space-y-3">
          <div className="text-center mb-4">
            <div className="text-gray-500 mb-2">Сетийн оноо</div>
            <div className="flex justify-center gap-3">
              <div className="text-2xl text-emerald-600">
                {sets.filter((s) => parseInt(s.teamA) > parseInt(s.teamB) && s.teamA && s.teamB).length}
              </div>
              <div className="text-2xl text-gray-300">-</div>
              <div className="text-2xl text-emerald-600">
                {sets.filter((s) => parseInt(s.teamB) > parseInt(s.teamA) && s.teamA && s.teamB).length}
              </div>
            </div>
          </div>

          {sets.map((set, index) => (
            <div key={index} className="flex items-center gap-2 bg-gray-50 p-3 rounded-lg">
              <span className="text-gray-500 min-w-[50px]">Сет {index + 1}</span>
              <Input
                type="number"
                value={set.teamA}
                onChange={(e) => updateSet(index, "teamA", e.target.value)}
                className="w-16 h-10 text-center"
                placeholder="0"
                min="0"
              />
              <span className="text-gray-400">:</span>
              <Input
                type="number"
                value={set.teamB}
                onChange={(e) => updateSet(index, "teamB", e.target.value)}
                className="w-16 h-10 text-center"
                placeholder="0"
                min="0"
              />
            </div>
          ))}
        </div>

        {/* Team B */}
        <Card className={`p-6 ${winner === "teamB" ? "border-2 border-emerald-500 bg-emerald-50" : "bg-gray-50"}`}>
          <div className="text-center mb-4">
            <div className="inline-block px-3 py-1 bg-gray-700 text-white rounded-full mb-3">
              Баг Б
            </div>
            <p className="text-gray-600">{teamB.club}</p>
          </div>
          <div className="space-y-3">
            <div className="flex items-center gap-3 p-3 bg-white rounded-lg">
              <Avatar className="w-12 h-12">
                <AvatarImage src={teamB.player1.photo} />
                <AvatarFallback>{teamB.player1.name[0]}</AvatarFallback>
              </Avatar>
              <div>
                <div className="text-gray-800">{teamB.player1.name}</div>
                <div className="text-gray-500">Тоглогч 1</div>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-white rounded-lg">
              <Avatar className="w-12 h-12">
                <AvatarImage src={teamB.player2.photo} />
                <AvatarFallback>{teamB.player2.name[0]}</AvatarFallback>
              </Avatar>
              <div>
                <div className="text-gray-800">{teamB.player2.name}</div>
                <div className="text-gray-500">Тоглогч 2</div>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Actions */}
      <div className="flex justify-end gap-3 pt-4 border-t">
        <Button variant="outline" onClick={onCancel}>
          <X className="w-4 h-4 mr-2" />
          Цуцлах
        </Button>
        <Button onClick={onSave} className="bg-emerald-600 hover:bg-emerald-700">
          <Save className="w-4 h-4 mr-2" />
          Үр дүн хадгалах
        </Button>
      </div>
    </div>
  );
}
