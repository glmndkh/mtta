import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { ScrollArea } from "./ui/scroll-area";
import { Trophy, Clock, CheckCircle2, AlertCircle } from "lucide-react";

export function SidePanel() {
  const matches = [
    {
      id: 1,
      player1: "Б. Энхболд",
      player2: "Д. Бат-Эрдэнэ",
      score: "3-1",
      status: "completed",
      time: "14:30",
    },
    {
      id: 2,
      player1: "Г. Мөнхбат",
      player2: "Ч. Өнөрбаяр",
      score: "2-3",
      status: "completed",
      time: "15:00",
    },
    {
      id: 3,
      player1: "Н. Түвшинбаяр",
      player2: "Л. Ганзориг",
      score: "-",
      status: "in-progress",
      time: "15:30",
    },
    {
      id: 4,
      player1: "А. Болорчулуун",
      player2: "С. Батбаяр",
      score: "-",
      status: "pending",
      time: "16:00",
    },
    {
      id: 5,
      player1: "О. Мөнхзул",
      player2: "Э. Төмөрбаатар",
      score: "-",
      status: "pending",
      time: "16:30",
    },
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return (
          <Badge className="bg-emerald-100 text-emerald-700 border-0">
            <CheckCircle2 className="w-3 h-3 mr-1" />
            Дууссан
          </Badge>
        );
      case "in-progress":
        return (
          <Badge className="bg-amber-100 text-amber-700 border-0">
            <Clock className="w-3 h-3 mr-1" />
            Явагдаж байна
          </Badge>
        );
      case "pending":
        return (
          <Badge className="bg-gray-100 text-gray-600 border-0">
            <AlertCircle className="w-3 h-3 mr-1" />
            Хүлээгдэж байна
          </Badge>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Live Bracket */}
      <Card className="p-6 bg-white shadow-lg">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center">
            <Trophy className="w-5 h-5 text-white" />
          </div>
          <h3 className="text-gray-900">Шигшээ үе шат</h3>
        </div>

        <div className="space-y-4">
          <div className="bg-gradient-to-r from-emerald-50 to-white p-4 rounded-xl border border-emerald-200">
            <div className="text-emerald-700 mb-2">Бүлэг А</div>
            <div className="space-y-2">
              <div className="flex justify-between items-center text-gray-700">
                <span>1. Б. Энхболд</span>
                <span className="text-emerald-600">9-0</span>
              </div>
              <div className="flex justify-between items-center text-gray-700">
                <span>2. Г. Мөнхбат</span>
                <span className="text-gray-600">6-3</span>
              </div>
              <div className="flex justify-between items-center text-gray-700">
                <span>3. Н. Түвшинбаяр</span>
                <span className="text-gray-600">3-6</span>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-gray-50 to-white p-4 rounded-xl border border-gray-200">
            <div className="text-gray-700 mb-2">Бүлэг Б</div>
            <div className="space-y-2">
              <div className="flex justify-between items-center text-gray-700">
                <span>1. Д. Бат-Эрдэнэ</span>
                <span className="text-emerald-600">8-1</span>
              </div>
              <div className="flex justify-between items-center text-gray-700">
                <span>2. Ч. Өнөрбаяр</span>
                <span className="text-gray-600">5-4</span>
              </div>
              <div className="flex justify-between items-center text-gray-700">
                <span>3. Л. Ганзориг</span>
                <span className="text-gray-600">2-7</span>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Match History */}
      <Card className="p-6 bg-white shadow-lg">
        <h3 className="text-gray-900 mb-4">Тоглолтын түүх</h3>
        <ScrollArea className="h-[400px] pr-4">
          <div className="space-y-3">
            {matches.map((match) => (
              <div
                key={match.id}
                className="p-4 bg-gray-50 rounded-xl border border-gray-200 hover:border-emerald-300 transition-colors"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="text-gray-500">{match.time}</div>
                  {getStatusBadge(match.status)}
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-800">{match.player1}</span>
                    {match.status === "completed" && (
                      <span className="text-emerald-600">
                        {match.score.split("-")[0]}
                      </span>
                    )}
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-800">{match.player2}</span>
                    {match.status === "completed" && (
                      <span className="text-gray-600">
                        {match.score.split("-")[1]}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </Card>
    </div>
  );
}
