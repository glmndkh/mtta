import { useState } from "react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { ArrowLeft, Trophy, Grid3x3 } from "lucide-react";
import { TournamentConfig } from "../App";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog";
import { MatchResultInput } from "./MatchResultInput";
import { BracketMatchCard } from "./BracketMatchCard";

interface PlayoffViewProps {
  config: TournamentConfig;
  onBack: () => void;
}

interface Match {
  id: string;
  participant1?: { name: string; photo: string; club: string };
  participant2?: { name: string; photo: string; club: string };
  score?: string;
  winner?: "participant1" | "participant2";
}

export function PlayoffView({ config, onBack }: PlayoffViewProps) {
  const [selectedMatch, setSelectedMatch] = useState<string | null>(null);
  const [showMatchDialog, setShowMatchDialog] = useState(false);

  const [matches] = useState<Record<string, Match>>({
    // Quarterfinals
    q1: {
      id: "q1",
      participant1: {
        name: config.eventType === "team" ? "Улаанбаатар клуб" : "Б. Энхболд",
        photo: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=100",
        club: "Улаанбаатар клуб",
      },
      participant2: {
        name: config.eventType === "team" ? "Эрдэнэт клуб" : "Л. Ганзориг",
        photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100",
        club: "Эрдэнэт клуб",
      },
      score: "3-0",
      winner: "participant1",
    },
    q2: {
      id: "q2",
      participant1: {
        name: config.eventType === "team" ? "Монгол Алтан клуб" : "Г. Мөнхбат",
        photo: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100",
        club: "Монгол Алтан клуб",
      },
      participant2: {
        name: config.eventType === "team" ? "Их Монгол клуб" : "Н. Түвшинбаяр",
        photo: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100",
        club: "Их Монгол клуб",
      },
      score: "3-2",
      winner: "participant1",
    },
    q3: {
      id: "q3",
      participant1: {
        name: config.eventType === "team" ? "Дархан клуб" : "Д. Бат-Эрдэнэ",
        photo: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100",
        club: "Дархан клуб",
      },
      participant2: {
        name: config.eventType === "team" ? "Төв клуб" : "Ч. Өнөрбаяр",
        photo: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=100",
        club: "Төв клуб",
      },
    },
    q4: {
      id: "q4",
      participant1: {
        name: config.eventType === "team" ? "Сэлэнгэ клуб" : "А. Болорчулуун",
        photo: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100",
        club: "Сэлэнгэ клуб",
      },
      participant2: {
        name: config.eventType === "team" ? "Өвөрхангай клуб" : "С. Батбаяр",
        photo: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=100",
        club: "Өвөрхангай клуб",
      },
    },
    // Semifinals
    s1: {
      id: "s1",
      participant1: {
        name: config.eventType === "team" ? "Улаанбаатар клуб" : "Б. Энхболд",
        photo: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=100",
        club: "Улаанбаатар клуб",
      },
      participant2: {
        name: config.eventType === "team" ? "Монгол Алтан клуб" : "Г. Мөнхбат",
        photo: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100",
        club: "Монгол Алтан клуб",
      },
    },
    s2: {
      id: "s2",
    },
    // Final
    final: {
      id: "final",
    },
    // Third Place
    third: {
      id: "third",
    },
  });

  const getEventTypeName = () => {
    switch (config.eventType) {
      case "singles":
        return "Ганцаарчилсан";
      case "team":
        return "Багийн";
      case "doubles":
        return "Хос";
    }
  };

  const getCategoryName = () => {
    switch (config.category) {
      case "men":
        return "Эрэгтэй";
      case "women":
        return "Эмэгтэй";
      case "u15":
        return "U15";
      case "veteran":
        return "Ахмадууд";
    }
  };

  const handleMatchClick = (matchId: string) => {
    setSelectedMatch(matchId);
    setShowMatchDialog(true);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-[1900px] mx-auto">
        {/* Header */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <div className="flex items-center justify-between">
            <Button
              variant="outline"
              onClick={onBack}
              className="border-gray-300 hover:border-emerald-500 h-11"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Буцах
            </Button>
            
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-emerald-600 to-emerald-700 rounded-xl flex items-center justify-center shadow-lg">
                <Grid3x3 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-gray-900">Шууд шат - Playoff Bracket</h1>
                <div className="flex items-center gap-3 mt-1">
                  <Badge className="bg-emerald-100 text-emerald-700 border-0">
                    {getEventTypeName()}
                  </Badge>
                  <Badge className="bg-blue-100 text-blue-700 border-0">
                    {getCategoryName()}
                  </Badge>
                </div>
              </div>
            </div>

            <div className="w-24"></div>
          </div>
        </div>

        {/* Bracket */}
        <Card className="p-10 bg-white shadow-2xl border-0">
          <div className="flex justify-between gap-12">
            {/* Left Side - Quarterfinals */}
            <div className="flex-1 space-y-8">
              <div className="text-center">
                <h3 className="text-gray-800 inline-block px-6 py-2 bg-gray-100 rounded-full">
                  Шилдэг 8 (Quarterfinals)
                </h3>
              </div>
              <div className="space-y-32">
                <BracketMatchCard
                  match={matches.q1}
                  onClick={() => handleMatchClick("q1")}
                  eventType={config.eventType}
                />
                <BracketMatchCard
                  match={matches.q2}
                  onClick={() => handleMatchClick("q2")}
                  eventType={config.eventType}
                />
              </div>
            </div>

            {/* Center - Semifinals */}
            <div className="flex-1 space-y-8">
              <div className="text-center">
                <h3 className="text-gray-800 inline-block px-6 py-2 bg-gray-100 rounded-full">
                  Хагас шигшээ (Semifinals)
                </h3>
              </div>
              <div className="space-y-64 pt-28">
                <BracketMatchCard
                  match={matches.s1}
                  onClick={() => handleMatchClick("s1")}
                  eventType={config.eventType}
                />
                <BracketMatchCard
                  match={matches.s2}
                  onClick={() => handleMatchClick("s2")}
                  eventType={config.eventType}
                />
              </div>
            </div>

            {/* Right - Finals */}
            <div className="flex-1 space-y-8">
              <div className="text-center">
                <h3 className="text-gray-800 inline-block px-6 py-2 bg-gradient-to-r from-emerald-600 to-emerald-700 text-white rounded-full shadow-lg">
                  Финал (Final)
                </h3>
              </div>
              <div className="pt-56 space-y-32">
                <BracketMatchCard
                  match={matches.final}
                  onClick={() => handleMatchClick("final")}
                  eventType={config.eventType}
                  isHighlight
                />
                <div>
                  <div className="text-center mb-6">
                    <h4 className="text-gray-700 inline-block px-4 py-1.5 bg-orange-100 rounded-full">
                      3-р байр
                    </h4>
                  </div>
                  <BracketMatchCard
                    match={matches.third}
                    onClick={() => handleMatchClick("third")}
                    eventType={config.eventType}
                  />
                </div>
              </div>
            </div>

            {/* Far Right - Quarterfinals */}
            <div className="flex-1 space-y-8">
              <div className="text-center">
                <h3 className="text-gray-800 inline-block px-6 py-2 bg-gray-100 rounded-full">
                  Шилдэг 8 (Quarterfinals)
                </h3>
              </div>
              <div className="space-y-32">
                <BracketMatchCard
                  match={matches.q3}
                  onClick={() => handleMatchClick("q3")}
                  eventType={config.eventType}
                />
                <BracketMatchCard
                  match={matches.q4}
                  onClick={() => handleMatchClick("q4")}
                  eventType={config.eventType}
                />
              </div>
            </div>
          </div>
        </Card>

        {/* Instructions */}
        <div className="mt-6 text-center">
          <p className="text-gray-600">
            💡 Тоглолтын үр дүн оруулахын тулд bracket дээрх тоглолт дээр дарна уу
          </p>
        </div>
      </div>

      {/* Match Result Dialog */}
      <Dialog open={showMatchDialog} onOpenChange={setShowMatchDialog}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-gray-900">Тоглолтын үр дүн оруулах</DialogTitle>
          </DialogHeader>
          <MatchResultInput
            eventType={config.eventType}
            onSave={() => setShowMatchDialog(false)}
            onCancel={() => setShowMatchDialog(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
