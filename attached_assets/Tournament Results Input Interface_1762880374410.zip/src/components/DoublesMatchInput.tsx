import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card } from "./ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Save, X, Trophy, Users } from "lucide-react";

interface DoublesMatchInputProps {
  onSave: () => void;
  onCancel: () => void;
}

interface SetScore {
  pair1: string;
  pair2: string;
}

export function DoublesMatchInput({ onSave, onCancel }: DoublesMatchInputProps) {
  const [sets, setSets] = useState<SetScore[]>([
    { pair1: "", pair2: "" },
    { pair1: "", pair2: "" },
    { pair1: "", pair2: "" },
  ]);

  const updateSet = (index: number, pair: "pair1" | "pair2", value: string) => {
    const newSets = [...sets];
    newSets[index][pair] = value;
    setSets(newSets);
  };

  const calculateWinner = () => {
    let pair1Wins = 0;
    let pair2Wins = 0;

    sets.forEach((set) => {
      const p1Score = parseInt(set.pair1) || 0;
      const p2Score = parseInt(set.pair2) || 0;
      if (p1Score > p2Score && set.pair1 && set.pair2) pair1Wins++;
      if (p2Score > p1Score && set.pair1 && set.pair2) pair2Wins++;
    });

    if (pair1Wins >= 3 && pair1Wins > pair2Wins) return "pair1";
    if (pair2Wins >= 3 && pair2Wins > pair1Wins) return "pair2";
    return null;
  };

  const winner = calculateWinner();

  const pair1 = {
    player1: {
      name: "Б. Энхболд",
      photo: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=200",
    },
    player2: {
      name: "Г. Мөнхбат",
      photo: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200",
    },
    club: "Улаанбаатар клуб",
  };

  const pair2 = {
    player1: {
      name: "Д. Бат-Эрдэнэ",
      photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200",
    },
    player2: {
      name: "Ч. Өнөрбаяр",
      photo: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200",
    },
    club: "Монгол Алтан клуб",
  };

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-[1fr_auto_1fr] gap-10">
        {/* Pair 1 */}
        <Card
          className={`p-6 transition-all ${
            winner === "pair1"
              ? "border-2 border-emerald-600 bg-gradient-to-br from-emerald-50 to-white shadow-xl"
              : "bg-gray-50 border border-gray-200"
          }`}
        >
          <div className="text-center mb-5">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-full mb-3 shadow-md">
              <Users className="w-4 h-4" />
              <span>Хос А</span>
            </div>
            <p className="text-gray-600">{pair1.club}</p>
          </div>

          <div className="space-y-4">
            <div className="flex items-center gap-4 p-4 bg-white rounded-xl shadow-sm">
              <Avatar className="w-16 h-16 border-2 border-white shadow-md">
                <AvatarImage src={pair1.player1.photo} />
                <AvatarFallback>{pair1.player1.name[0]}</AvatarFallback>
              </Avatar>
              <div>
                <div className="text-gray-900">{pair1.player1.name}</div>
                <div className="text-gray-500">Тоглогч 1</div>
              </div>
            </div>

            <div className="flex items-center gap-4 p-4 bg-white rounded-xl shadow-sm">
              <Avatar className="w-16 h-16 border-2 border-white shadow-md">
                <AvatarImage src={pair1.player2.photo} />
                <AvatarFallback>{pair1.player2.name[0]}</AvatarFallback>
              </Avatar>
              <div>
                <div className="text-gray-900">{pair1.player2.name}</div>
                <div className="text-gray-500">Тоглогч 2</div>
              </div>
            </div>
          </div>

          {winner === "pair1" && (
            <div className="mt-5 text-center">
              <div className="inline-flex items-center gap-2 px-5 py-2 bg-emerald-600 text-white rounded-full shadow-lg">
                <Trophy className="w-4 h-4" />
                <span>Ялагч</span>
              </div>
            </div>
          )}
        </Card>

        {/* Score Input */}
        <div className="min-w-[280px] space-y-4">
          <div className="text-center mb-6 p-4 bg-gray-50 rounded-xl">
            <div className="text-gray-600 mb-2">Сетийн оноо</div>
            <div className="flex justify-center items-center gap-4">
              <div className="text-3xl text-emerald-700">
                {sets.filter((s) => parseInt(s.pair1) > parseInt(s.pair2) && s.pair1 && s.pair2).length}
              </div>
              <div className="text-3xl text-gray-400">-</div>
              <div className="text-3xl text-emerald-700">
                {sets.filter((s) => parseInt(s.pair2) > parseInt(s.pair1) && s.pair1 && s.pair2).length}
              </div>
            </div>
          </div>

          {sets.map((set, index) => (
            <Card key={index} className="p-4 bg-white border-gray-200 shadow-sm">
              <div className="flex items-center gap-3">
                <span className="text-gray-600 min-w-[60px]">Сет {index + 1}</span>
                <Input
                  type="number"
                  value={set.pair1}
                  onChange={(e) => updateSet(index, "pair1", e.target.value)}
                  className="w-20 h-12 text-center text-lg border-gray-300"
                  placeholder="0"
                  min="0"
                />
                <span className="text-gray-400">:</span>
                <Input
                  type="number"
                  value={set.pair2}
                  onChange={(e) => updateSet(index, "pair2", e.target.value)}
                  className="w-20 h-12 text-center text-lg border-gray-300"
                  placeholder="0"
                  min="0"
                />
              </div>
            </Card>
          ))}
        </div>

        {/* Pair 2 */}
        <Card
          className={`p-6 transition-all ${
            winner === "pair2"
              ? "border-2 border-emerald-600 bg-gradient-to-br from-emerald-50 to-white shadow-xl"
              : "bg-gray-50 border border-gray-200"
          }`}
        >
          <div className="text-center mb-5">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-gray-700 text-white rounded-full mb-3 shadow-md">
              <Users className="w-4 h-4" />
              <span>Хос Б</span>
            </div>
            <p className="text-gray-600">{pair2.club}</p>
          </div>

          <div className="space-y-4">
            <div className="flex items-center gap-4 p-4 bg-white rounded-xl shadow-sm">
              <Avatar className="w-16 h-16 border-2 border-white shadow-md">
                <AvatarImage src={pair2.player1.photo} />
                <AvatarFallback>{pair2.player1.name[0]}</AvatarFallback>
              </Avatar>
              <div>
                <div className="text-gray-900">{pair2.player1.name}</div>
                <div className="text-gray-500">Тоглогч 1</div>
              </div>
            </div>

            <div className="flex items-center gap-4 p-4 bg-white rounded-xl shadow-sm">
              <Avatar className="w-16 h-16 border-2 border-white shadow-md">
                <AvatarImage src={pair2.player2.photo} />
                <AvatarFallback>{pair2.player2.name[0]}</AvatarFallback>
              </Avatar>
              <div>
                <div className="text-gray-900">{pair2.player2.name}</div>
                <div className="text-gray-500">Тоглогч 2</div>
              </div>
            </div>
          </div>

          {winner === "pair2" && (
            <div className="mt-5 text-center">
              <div className="inline-flex items-center gap-2 px-5 py-2 bg-emerald-600 text-white rounded-full shadow-lg">
                <Trophy className="w-4 h-4" />
                <span>Ялагч</span>
              </div>
            </div>
          )}
        </Card>
      </div>

      {/* Actions */}
      <div className="flex justify-end gap-3 pt-6 border-t border-gray-200">
        <Button variant="outline" onClick={onCancel} className="h-12 px-6 border-gray-300">
          <X className="w-4 h-4 mr-2" />
          Цуцлах
        </Button>
        <Button onClick={onSave} className="bg-emerald-600 hover:bg-emerald-700 h-12 px-8 shadow-lg">
          <Save className="w-4 h-4 mr-2" />
          Үр дүн хадгалах
        </Button>
      </div>
    </div>
  );
}
