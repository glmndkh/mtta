import { useState } from "react";
import { Button } from "./ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import { Card } from "./ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { ArrowLeft, Plus, Trophy, CheckCircle2, XCircle } from "lucide-react";
import { EventType } from "../App";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog";
import { MatchResultForm } from "./MatchResultForm";

interface GroupStageProps {
  eventType: EventType;
  onBack: () => void;
}

interface Standing {
  id: number;
  name: string;
  photo: string;
  club: string;
  mp: number;
  w: number;
  l: number;
  sd: number;
  pts: number;
  qualified: boolean;
}

export function GroupStage({ eventType, onBack }: GroupStageProps) {
  const [selectedGroup, setSelectedGroup] = useState("A");
  const [showMatchDialog, setShowMatchDialog] = useState(false);

  const standings: Standing[] = [
    {
      id: 1,
      name: "Б. Энхболд",
      photo: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=100",
      club: "Улаанбаатар клуб",
      mp: 3,
      w: 3,
      l: 0,
      sd: 9,
      pts: 9,
      qualified: true,
    },
    {
      id: 2,
      name: "Г. Мөнхбат",
      photo: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100",
      club: "Монгол Алтан клуб",
      mp: 3,
      w: 2,
      l: 1,
      sd: 3,
      pts: 6,
      qualified: true,
    },
    {
      id: 3,
      name: "Н. Түвшинбаяр",
      photo: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100",
      club: "Их Монгол клуб",
      mp: 3,
      w: 1,
      l: 2,
      sd: -3,
      pts: 3,
      qualified: false,
    },
    {
      id: 4,
      name: "Л. Ганзориг",
      photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100",
      club: "Эрдэнэт клуб",
      mp: 3,
      w: 0,
      l: 3,
      sd: -9,
      pts: 0,
      qualified: false,
    },
  ];

  const getEventTypeName = () => {
    switch (eventType) {
      case "single":
        return "Ганцаарчилсан";
      case "team":
        return "Баг";
      case "doubles":
        return "Хос";
    }
  };

  return (
    <div className="min-h-screen p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button
            variant="outline"
            onClick={onBack}
            className="border-gray-300 hover:border-emerald-500"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Буцах
          </Button>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-emerald-600 rounded-xl flex items-center justify-center">
              <Trophy className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-gray-900">Шигшээ хүртэлх хэсгийн тоглолт</h1>
              <p className="text-gray-600">{getEventTypeName()} - Бүлгийн хүснэгт</p>
            </div>
          </div>
          <div className="w-32"></div>
        </div>

        {/* Controls */}
        <Card className="p-6 mb-6 bg-white shadow-lg border-gray-200">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-4 flex-1">
              <div className="flex-1 max-w-xs">
                <label className="text-gray-700 mb-2 block">Бүлэг сонгох</label>
                <Select value={selectedGroup} onValueChange={setSelectedGroup}>
                  <SelectTrigger className="h-12 bg-white border-gray-300">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="A">Бүлэг А</SelectItem>
                    <SelectItem value="B">Бүлэг Б</SelectItem>
                    <SelectItem value="C">Бүлэг С</SelectItem>
                    <SelectItem value="D">Бүлэг Д</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button
              onClick={() => setShowMatchDialog(true)}
              className="bg-emerald-600 hover:bg-emerald-700 h-12 px-8"
            >
              <Plus className="w-5 h-5 mr-2" />
              Тоглолтын үр дүн нэмэх
            </Button>
          </div>
        </Card>

        {/* Standings Table */}
        <Card className="bg-white shadow-xl border-gray-200 overflow-hidden">
          <div className="p-6 bg-gradient-to-r from-emerald-600 to-emerald-700">
            <h2 className="text-white">Бүлэг {selectedGroup} - Байрлал</h2>
          </div>

          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50 hover:bg-gray-50">
                  <TableHead className="w-12 text-center">#</TableHead>
                  <TableHead className="min-w-[280px]">
                    {eventType === "team" ? "Багийн нэр" : "Тоглогчийн нэр"}
                  </TableHead>
                  <TableHead className="text-center">MP</TableHead>
                  <TableHead className="text-center">W</TableHead>
                  <TableHead className="text-center">L</TableHead>
                  <TableHead className="text-center">SD</TableHead>
                  <TableHead className="text-center">PTS</TableHead>
                  <TableHead className="text-center">Статус</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {standings.map((standing, index) => (
                  <TableRow
                    key={standing.id}
                    className={`${
                      standing.qualified ? "bg-emerald-50/50" : ""
                    } hover:bg-gray-50 transition-colors`}
                  >
                    <TableCell className="text-center">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center mx-auto ${
                          index === 0
                            ? "bg-amber-500 text-white"
                            : index === 1
                            ? "bg-gray-400 text-white"
                            : index === 2
                            ? "bg-orange-600 text-white"
                            : "bg-gray-200 text-gray-600"
                        }`}
                      >
                        {index + 1}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-4">
                        <Avatar className="w-12 h-12 border-2 border-white shadow-md">
                          <AvatarImage src={standing.photo} />
                          <AvatarFallback>{standing.name[0]}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="text-gray-900">{standing.name}</div>
                          <div className="text-gray-500">{standing.club}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-center text-gray-700">
                      {standing.mp}
                    </TableCell>
                    <TableCell className="text-center text-emerald-600">
                      {standing.w}
                    </TableCell>
                    <TableCell className="text-center text-red-600">
                      {standing.l}
                    </TableCell>
                    <TableCell className="text-center">
                      <span
                        className={
                          standing.sd > 0
                            ? "text-emerald-600"
                            : standing.sd < 0
                            ? "text-red-600"
                            : "text-gray-600"
                        }
                      >
                        {standing.sd > 0 ? "+" : ""}
                        {standing.sd}
                      </span>
                    </TableCell>
                    <TableCell className="text-center text-gray-900">
                      {standing.pts}
                    </TableCell>
                    <TableCell className="text-center">
                      {standing.qualified ? (
                        <Badge className="bg-emerald-100 text-emerald-700 border-0">
                          <CheckCircle2 className="w-3 h-3 mr-1" />
                          Шигшсэн
                        </Badge>
                      ) : (
                        <Badge className="bg-red-100 text-red-700 border-0">
                          <XCircle className="w-3 h-3 mr-1" />
                          Хасагдсан
                        </Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </Card>

        {/* Legend */}
        <div className="mt-6 flex items-center justify-center gap-8 text-gray-600">
          <div className="flex items-center gap-2">
            <span>MP = Matches Played</span>
          </div>
          <div className="flex items-center gap-2">
            <span>W = Wins</span>
          </div>
          <div className="flex items-center gap-2">
            <span>L = Losses</span>
          </div>
          <div className="flex items-center gap-2">
            <span>SD = Set Difference</span>
          </div>
          <div className="flex items-center gap-2">
            <span>PTS = Points</span>
          </div>
        </div>
      </div>

      {/* Match Result Dialog */}
      <Dialog open={showMatchDialog} onOpenChange={setShowMatchDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Тоглолтын үр дүн оруулах - Бүлэг {selectedGroup}</DialogTitle>
          </DialogHeader>
          <MatchResultForm
            eventType={eventType}
            onSave={() => setShowMatchDialog(false)}
            onCancel={() => setShowMatchDialog(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
