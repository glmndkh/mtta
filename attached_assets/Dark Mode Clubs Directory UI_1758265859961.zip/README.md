
  # Dark Mode Clubs Directory UI

  This is a code bundle for Dark Mode Clubs Directory UI. The original project is available at https://www.figma.com/design/Yl7LgQBRqdWQ5KSVlJvRld/Dark-Mode-Clubs-Directory-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  