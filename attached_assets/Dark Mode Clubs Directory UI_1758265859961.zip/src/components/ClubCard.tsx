import { Phone, Mail, Globe, Facebook, Instagram, MapPin } from "lucide-react";
import { Card, CardContent, CardFooter } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Separator } from "./ui/separator";
import { OpeningHours, OpeningHours as OpeningHoursType } from "./OpeningHours";

export interface Club {
  id: string;
  name: string;
  logo: string;
  status: "active" | "inactive";
  city: string;
  owner: string;
  headCoaches: string[];
  tags: string[];
  phone?: string;
  email?: string;
  website?: string;
  facebook?: string;
  instagram?: string;
  location: string;
  openingHours: OpeningHoursType;
}

interface ClubCardProps {
  club: Club;
}

export function ClubCard({ club }: ClubCardProps) {
  const statusConfig = {
    active: { label: "Идэвхтэй", className: "bg-green-500/10 text-green-500 border-green-500/20" },
    inactive: { label: "Идэвхгүй", className: "bg-gray-500/10 text-gray-500 border-gray-500/20" }
  };

  const currentStatus = statusConfig[club.status];

  return (
    <Card className="h-full flex flex-col">
      <CardContent className="p-4 flex-1">
        <div className="flex items-start gap-3 mb-4">
          <div className="w-12 h-12 rounded-lg bg-muted flex items-center justify-center overflow-hidden flex-shrink-0">
            <img
              src={club.logo}
              alt={club.name}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-foreground truncate mb-2">
              {club.name}
            </h3>
            <div className="flex flex-wrap gap-2 mb-1">
              <Badge variant="outline" className={currentStatus.className}>
                {currentStatus.label}
              </Badge>
              <Badge variant="secondary" className="text-xs">
                {club.city}
              </Badge>
            </div>
          </div>
        </div>

        <OpeningHours hours={club.openingHours} />

        <div className="space-y-2 mb-4">
          <div>
            <span className="text-sm text-muted-foreground">Эзэмшигч: </span>
            <span className="text-sm text-foreground">{club.owner}</span>
          </div>
          <div>
            <span className="text-sm text-muted-foreground">Ахлах дасгалжуулагч: </span>
            <span className="text-sm text-foreground">
              {club.headCoaches.slice(0, 2).join(", ")}
              {club.headCoaches.length > 2 && " ..."}
            </span>
          </div>
        </div>

        <div className="flex flex-wrap gap-1 mb-4">
          {club.tags.map((tag, index) => (
            <Badge
              key={index}
              variant="secondary"
              className="text-xs bg-muted text-muted-foreground"
            >
              {tag}
            </Badge>
          ))}
        </div>

        <Separator className="mb-4" />

        <div className="flex flex-wrap gap-1">
          {club.phone && (
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <Phone className="h-4 w-4" />
            </Button>
          )}
          {club.email && (
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <Mail className="h-4 w-4" />
            </Button>
          )}
          {club.website && (
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <Globe className="h-4 w-4" />
            </Button>
          )}
          {club.facebook && (
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <Facebook className="h-4 w-4" />
            </Button>
          )}
          {club.instagram && (
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <Instagram className="h-4 w-4" />
            </Button>
          )}
        </div>
      </CardContent>

      <CardFooter className="p-4 pt-0 flex justify-between items-center">
        <div className="flex items-center gap-1 text-sm text-muted-foreground">
          <MapPin className="h-3 w-3" />
          <span className="truncate">{club.location}</span>
        </div>
        <Badge variant="outline" className={currentStatus.className}>
          {currentStatus.label}
        </Badge>
      </CardFooter>
    </Card>
  );
}