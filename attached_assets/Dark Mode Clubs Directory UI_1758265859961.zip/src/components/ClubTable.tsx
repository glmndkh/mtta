import { Badge } from "./ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Club } from "./ClubCard";
import { OpeningHours } from "./OpeningHours";

interface ClubTableProps {
  clubs: Club[];
}

export function ClubTable({ clubs }: ClubTableProps) {
  const statusConfig = {
    active: { label: "Идэвхтэй", className: "bg-green-500/10 text-green-500 border-green-500/20" },
    inactive: { label: "Идэвхгүй", className: "bg-gray-500/10 text-gray-500 border-gray-500/20" }
  };

  return (
    <div className="rounded-lg border bg-card overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[60px]">Лого</TableHead>
            <TableHead>Нэр</TableHead>
            <TableHead>Хот</TableHead>
            <TableHead>Эзэмшигч</TableHead>
            <TableHead>Ахлах дасгалжуулагч</TableHead>
            <TableHead>Утас</TableHead>
            <TableHead>Цаг</TableHead>
            <TableHead className="text-right">Төлөв</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {clubs.map((club) => (
            <TableRow key={club.id}>
              <TableCell>
                <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center overflow-hidden">
                  <img
                    src={club.logo}
                    alt={club.name}
                    className="w-full h-full object-cover"
                  />
                </div>
              </TableCell>
              <TableCell className="font-medium">
                <div className="truncate max-w-[200px]">{club.name}</div>
              </TableCell>
              <TableCell>
                <Badge variant="secondary" className="text-xs">
                  {club.city}
                </Badge>
              </TableCell>
              <TableCell>{club.owner}</TableCell>
              <TableCell>
                <div className="truncate max-w-[150px]">
                  {club.headCoaches.slice(0, 2).join(", ")}
                  {club.headCoaches.length > 2 && " ..."}
                </div>
              </TableCell>
              <TableCell>{club.phone || "—"}</TableCell>
              <TableCell>
                <OpeningHours hours={club.openingHours} compact />
              </TableCell>
              <TableCell className="text-right">
                <Badge variant="outline" className={statusConfig[club.status].className}>
                  {statusConfig[club.status].label}
                </Badge>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}