interface HeaderProps {
  totalCount: number;
}

export function Header({ totalCount }: HeaderProps) {
  return (
    <div className="flex items-center justify-between mb-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground mb-1">Клубууд</h1>
        <p className="text-muted-foreground">
          Спортын клубуудын бүртгэл
        </p>
      </div>
      <div className="text-right">
        <div className="text-2xl font-bold text-foreground">{totalCount}</div>
        <div className="text-sm text-muted-foreground">клуб</div>
      </div>
    </div>
  );
}