import { useState } from "react";
import { Clock, ChevronDown } from "lucide-react";
import { Badge } from "./ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "./ui/tooltip";

export interface OpeningHours {
  [key: string]: { open: string; close: string }[] | null; // null means closed
}

export interface OpeningHoursProps {
  hours: OpeningHours;
  compact?: boolean;
}

const DAYS = [
  { key: 'monday', label: 'Даваа' },
  { key: 'tuesday', label: 'Мягмар' },
  { key: 'wednesday', label: 'Лхагва' },
  { key: 'thursday', label: 'Пүрэв' },
  { key: 'friday', label: 'Баасан' },
  { key: 'saturday', label: 'Бямба' },
  { key: 'sunday', label: 'Ням' }
];

function getCurrentDay(): string {
  const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  return days[new Date().getDay()];
}

function isCurrentlyOpen(hours: OpeningHours): boolean {
  const today = getCurrentDay();
  const todayHours = hours[today];
  
  if (!todayHours || todayHours.length === 0) return false;
  
  const now = new Date();
  const currentTime = now.getHours() * 60 + now.getMinutes();
  
  return todayHours.some(({ open, close }) => {
    const [openHour, openMin] = open.split(':').map(Number);
    const [closeHour, closeMin] = close.split(':').map(Number);
    const openTime = openHour * 60 + openMin;
    const closeTime = closeHour * 60 + closeMin;
    
    return currentTime >= openTime && currentTime < closeTime;
  });
}

function getTodayHours(hours: OpeningHours): string {
  const today = getCurrentDay();
  const todayHours = hours[today];
  
  if (!todayHours || todayHours.length === 0) {
    return "Хаалттай";
  }
  
  return todayHours.map(({ open, close }) => `${open}–${close}`).join(', ');
}

function formatHours(dayHours: { open: string; close: string }[] | null): string {
  if (!dayHours || dayHours.length === 0) return "–";
  return dayHours.map(({ open, close }) => `${open}–${close}`).join(', ');
}

export function OpeningHours({ hours, compact = false }: OpeningHoursProps) {
  const [isOpen, setIsOpen] = useState(false);
  const isCurrentlyOpenNow = isCurrentlyOpen(hours);
  const todayHours = getTodayHours(hours);

  const statusConfig = {
    open: { label: "Одоо нээлттэй", className: "bg-green-500/10 text-green-500 border-green-500/20" },
    closed: { label: "Хаалттай", className: "bg-gray-500/10 text-gray-500 border-gray-500/20" }
  };

  const currentStatus = statusConfig[isCurrentlyOpenNow ? 'open' : 'closed'];

  if (compact) {
    return (
      <div className="flex items-center gap-2">
        <span className="text-sm text-foreground">
          {todayHours === "Хаалттай" ? "Хаалттай" : `Өнөөдөр ${todayHours}`}
        </span>
        <Badge variant="outline" className={currentStatus.className}>
          {currentStatus.label}
        </Badge>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2 mb-3">
      <Badge variant="outline" className={currentStatus.className}>
        {currentStatus.label}
      </Badge>
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <span className="text-sm text-muted-foreground">
              Өнөөдөр: {todayHours}
            </span>
          </TooltipTrigger>
          <TooltipContent>
            <p>Asia/Ulaanbaatar цагийн бүс</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
      
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <button className="inline-flex items-center justify-center h-6 px-2 text-xs text-muted-foreground hover:text-foreground hover:bg-accent rounded-md transition-colors cursor-pointer">
            <Clock className="h-3 w-3 mr-1" />
            Цагийн хуваарь
            <ChevronDown className="h-3 w-3 ml-1" />
          </button>
        </PopoverTrigger>
        <PopoverContent className="w-64 p-3" align="start">
          <div className="space-y-2">
            <h4 className="font-medium text-sm mb-3">Цагийн хуваарь</h4>
            {DAYS.map(({ key, label }) => (
              <div key={key} className="flex justify-between items-center text-sm">
                <span className="text-muted-foreground">{label}</span>
                <span className="text-foreground">{formatHours(hours[key])}</span>
              </div>
            ))}
            <div className="pt-2 border-t text-xs text-muted-foreground">
              Asia/Ulaanbaatar цагийн бүс
            </div>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}