import { Club } from "../components/ClubCard";

export const mockClubs: Club[] = [
  {
    id: "1",
    name: "Монгол Алтан Хааны Клуб",
    logo: "https://images.unsplash.com/photo-1611762348135-5b09d2f0390d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0YWJsZSUyMHRlbm5pcyUyMHBhZGRsZSUyMGxvZ298ZW58MXx8fHwxNzU4MjYxMjczfDA&ixlib=rb-4.1.0&q=80&w=200",
    status: "active",
    city: "Улаанбаатар",
    owner: "Б.Цэвээнжав",
    headCoaches: ["Д.Батбаяр", "Г.Оюунчимэг"],
    tags: ["Олимпийн бэлтгэл", "Залуучуудын хөгжүүлэлт", "Мэргэжлийн"],
    phone: "+976-9999-1234",
    email: "info@goldenkhan.mn",
    website: "https://goldenkhan.mn",
    facebook: "goldenkhanclub",
    instagram: "goldenkhan_tt",
    location: "СБД, 1-р хороо",
    openingHours: {
      monday: [{ open: "08:00", close: "22:00" }],
      tuesday: [{ open: "08:00", close: "22:00" }],
      wednesday: [{ open: "08:00", close: "22:00" }],
      thursday: [{ open: "08:00", close: "22:00" }],
      friday: [{ open: "08:00", close: "22:00" }],
      saturday: [{ open: "10:00", close: "20:00" }],
      sunday: [{ open: "10:00", close: "18:00" }]
    }
  },
  {
    id: "2",
    name: "Эрдэнэт Ширээний Теннис",
    logo: "https://images.unsplash.com/photo-1611762348135-5b09d2f0390d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0YWJsZSUyMHRlbm5pcyUyMHBhZGRsZSUyMGxvZ298ZW58MXx8fHwxNzU4MjYxMjczfDA&ixlib=rb-4.1.0&q=80&w=200",
    status: "active",
    city: "Эрдэнэт",
    owner: "С.Энхбаяр",
    headCoaches: ["М.Алтанцэцэг"],
    tags: ["Хотын лига", "Амьсгалах хугацаа"],
    phone: "+976-7035-5678",
    email: "erdenet.tt@gmail.com",
    location: "Эрдэнэт хот, 15-р бөөм",
    openingHours: {
      monday: [{ open: "09:00", close: "21:00" }],
      tuesday: [{ open: "09:00", close: "21:00" }],
      wednesday: [{ open: "09:00", close: "21:00" }],
      thursday: [{ open: "09:00", close: "21:00" }],
      friday: [{ open: "09:00", close: "21:00" }],
      saturday: [{ open: "10:00", close: "19:00" }],
      sunday: null
    }
  },
  {
    id: "3",
    name: "Их Сургуулийн Спортын Клуб",
    logo: "https://images.unsplash.com/photo-1611762348135-5b09d2f0390d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0YWJsZSUyMHRlbm5pcyUyMHBhZGRsZSUyMGxvZ298ZW58MXx8fHwxNzU4MjYxMjczfDA&ixlib=rb-4.1.0&q=80&w=200",
    status: "inactive",
    city: "Улаанбаатар",
    owner: "Ж.Баатарсүх",
    headCoaches: ["П.Мөнхбат", "Ц.Сайханбилэг", "Н.Ганболд"],
    tags: ["Оюутнууд", "Бага төлбөртэй"],
    phone: "+976-11-123456",
    email: "university.sports@num.edu.mn",
    website: "https://sport.num.edu.mn",
    location: "ШУА, Спортын ордон",
    openingHours: {
      monday: [{ open: "16:00", close: "20:00" }],
      tuesday: [{ open: "16:00", close: "20:00" }],
      wednesday: [{ open: "16:00", close: "20:00" }],
      thursday: [{ open: "16:00", close: "20:00" }],
      friday: [{ open: "16:00", close: "20:00" }],
      saturday: null,
      sunday: null
    }
  },
  {
    id: "4",
    name: "Дархан Теннисний Төв",
    logo: "https://images.unsplash.com/photo-1611762348135-5b09d2f0390d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0YWJsZSUyMHRlbm5pcyUyMHBhZGRsZSUyMGxvZ298ZW58MXx8fHwxNzU4MjYxMjczfDA&ixlib=rb-4.1.0&q=80&w=200",
    status: "active",
    city: "Дархан",
    owner: "Л.Нямдаваа",
    headCoaches: ["Р.Бат-Эрдэнэ"],
    tags: ["Орон нутгийн", "Залуучууд"],
    phone: "+976-7037-9999",
    location: "Дархан-Уул аймаг",
    openingHours: {
      monday: [{ open: "10:00", close: "18:00" }],
      tuesday: [{ open: "10:00", close: "18:00" }],
      wednesday: [{ open: "10:00", close: "18:00" }],
      thursday: [{ open: "10:00", close: "18:00" }],
      friday: [{ open: "10:00", close: "18:00" }],
      saturday: [{ open: "10:00", close: "16:00" }],
      sunday: [{ open: "12:00", close: "16:00" }]
    }
  },
  {
    id: "5",
    name: "Премиум Ширээний Теннис Академи",
    logo: "https://images.unsplash.com/photo-1611762348135-5b09d2f0390d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0YWJsZSUyMHRlbm5pcyUyMHBhZGRsZSUyMGxvZ298ZW58MXx8fHwxNzU4MjYxMjczfDA&ixlib=rb-4.1.0&q=80&w=200",
    status: "active",
    city: "Улаанбаатар",
    owner: "И.Баярмагнай",
    headCoaches: ["Х.Гантөмөр", "А.Мөнхзул"],
    tags: ["Премиум", "Хувийн дасгалжуулагч", "VIP үйлчилгээ"],
    phone: "+976-8888-0001",
    email: "info@premiumtt.mn",
    website: "https://premiumtt.mn",
    facebook: "premiumttacademy",
    instagram: "premium_tt_mn",
    location: "ХУД, Зайсан толгой",
    openingHours: {
      monday: [{ open: "06:00", close: "12:00" }, { open: "14:00", close: "23:00" }],
      tuesday: [{ open: "06:00", close: "12:00" }, { open: "14:00", close: "23:00" }],
      wednesday: [{ open: "06:00", close: "12:00" }, { open: "14:00", close: "23:00" }],
      thursday: [{ open: "06:00", close: "12:00" }, { open: "14:00", close: "23:00" }],
      friday: [{ open: "06:00", close: "12:00" }, { open: "14:00", close: "23:00" }],
      saturday: [{ open: "08:00", close: "22:00" }],
      sunday: [{ open: "08:00", close: "20:00" }]
    }
  },
  {
    id: "6",
    name: "Ховд Аймгийн Спортын Клуб",
    logo: "https://images.unsplash.com/photo-1611762348135-5b09d2f0390d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0YWJsZSUyMHRlbm5pcyUyMHBhZGRsZSUyMGxvZ298ZW58MXx8fHwxNzU4MjYxMjczfDA&ixlib=rb-4.1.0&q=80&w=200",
    status: "active",
    city: "Ховд",
    owner: "Т.Алтангэрэл",
    headCoaches: ["У.Цэрэнбат"],
    tags: ["Баруун бүс", "Уламжлалт"],
    phone: "+976-7043-2222",
    location: "Ховд аймаг, төв",
    openingHours: {
      monday: [{ open: "14:00", close: "20:00" }],
      tuesday: [{ open: "14:00", close: "20:00" }],
      wednesday: [{ open: "14:00", close: "20:00" }],
      thursday: [{ open: "14:00", close: "20:00" }],
      friday: [{ open: "14:00", close: "20:00" }],
      saturday: [{ open: "10:00", close: "18:00" }],
      sunday: [{ open: "10:00", close: "18:00" }]
    }
  },
  {
    id: "7",
    name: "Чингисийн Хүүхдийн Спорт",
    logo: "https://images.unsplash.com/photo-1611762348135-5b09d2f0390d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0YWJsZSUyMHRlbm5pcyUyMHBhZGRsZSUyMGxvZ298ZW58MXx8fHwxNzU4MjYxMjczfDA&ixlib=rb-4.1.0&q=80&w=200",
    status: "inactive",
    city: "Улаанбаатар",
    owner: "О.Болдбаяр",
    headCoaches: ["Ч.Нарангэрэл"],
    tags: ["Хүүхдийн спорт", "7-15 нас"],
    phone: "+976-9900-3333",
    email: "kids@chinggis.sport",
    location: "БГД, Спортын сургууль",
    openingHours: {
      monday: null,
      tuesday: [{ open: "15:00", close: "18:00" }],
      wednesday: [{ open: "15:00", close: "18:00" }],
      thursday: [{ open: "15:00", close: "18:00" }],
      friday: [{ open: "15:00", close: "18:00" }],
      saturday: [{ open: "09:00", close: "15:00" }],
      sunday: [{ open: "09:00", close: "15:00" }]
    }
  },
  {
    id: "8",
    name: "Мэргэжлийн Теннисчдийн Холбоо",
    logo: "https://images.unsplash.com/photo-1611762348135-5b09d2f0390d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0YWJsZSUyMHRlbm5pcyUyMHBhZGRsZSUyMGxvZ298ZW58MXx8fHwxNzU4MjYxMjczfDA&ixlib=rb-4.1.0&q=80&w=200",
    status: "active",
    city: "Улаанбаатар",
    owner: "Д.Сүхбаатар",
    headCoaches: ["Б.Мөнхтөр", "Г.Батцэцэг", "Н.Энхбаяр"],
    tags: ["Мэргэжлийн", "Уралдаан", "Олон улсын"],
    phone: "+976-7000-1111",
    email: "pro@mongoltt.org",
    website: "https://mongoltt.org",
    facebook: "mongolianttassociation",
    location: "СБД, Спортын ордон",
    openingHours: {
      monday: [{ open: "07:00", close: "21:00" }],
      tuesday: [{ open: "07:00", close: "21:00" }],
      wednesday: [{ open: "07:00", close: "21:00" }],
      thursday: [{ open: "07:00", close: "21:00" }],
      friday: [{ open: "07:00", close: "21:00" }],
      saturday: [{ open: "08:00", close: "20:00" }],
      sunday: [{ open: "08:00", close: "18:00" }]
    }
  },
  {
    id: "9",
    name: "Цагаан Сарын Клуб",
    logo: "https://images.unsplash.com/photo-1611762348135-5b09d2f0390d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0YWJsZSUyMHRlbm5pcyUyMHBhZGRsZSUyMGxvZ298ZW58MXx8fHwxNzU4MjYxMjczfDA&ixlib=rb-4.1.0&q=80&w=200",
    status: "active",
    city: "Улаанбаатар",
    owner: "З.Цагаанбаатар",
    headCoaches: ["М.Эрдэнэбат"],
    tags: ["Төрөлхтний спорт", "Уламжлалт"],
    phone: "+976-9955-7777",
    location: "ХУД, 14-р хороо",
    openingHours: {
      monday: [{ open: "18:00", close: "22:00" }],
      tuesday: [{ open: "18:00", close: "22:00" }],
      wednesday: [{ open: "18:00", close: "22:00" }],
      thursday: [{ open: "18:00", close: "22:00" }],
      friday: [{ open: "18:00", close: "22:00" }],
      saturday: [{ open: "10:00", close: "22:00" }],
      sunday: [{ open: "10:00", close: "18:00" }]
    }
  }
];