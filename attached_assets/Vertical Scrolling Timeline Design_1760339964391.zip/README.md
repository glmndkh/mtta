
  # Vertical Scrolling Timeline Design

  This is a code bundle for Vertical Scrolling Timeline Design. The original project is available at https://www.figma.com/design/7WPfGANiwzCYmbYYE9hdhQ/Vertical-Scrolling-Timeline-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  