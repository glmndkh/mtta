import { MTTATimelineSection } from "./components/mtta-timeline-section";

export default function App() {
  return (
    <div className="min-h-screen">
      <MTTATimelineSection />
    </div>
  );
}
